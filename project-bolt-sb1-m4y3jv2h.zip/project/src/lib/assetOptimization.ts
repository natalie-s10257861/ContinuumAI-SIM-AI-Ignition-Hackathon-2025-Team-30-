export interface PlatformSpec {
  name: string;
  width: number;
  height: number;
  aspectRatio: string;
  maxSize: number;
  formats: string[];
}

export const PLATFORM_SPECS: Record<string, PlatformSpec> = {
  twitter: {
    name: 'Twitter',
    width: 1200,
    height: 675,
    aspectRatio: '16:9',
    maxSize: 5 * 1024 * 1024,
    formats: ['jpg', 'png', 'gif'],
  },
  linkedin: {
    name: 'LinkedIn',
    width: 1200,
    height: 627,
    aspectRatio: '1.91:1',
    maxSize: 10 * 1024 * 1024,
    formats: ['jpg', 'png', 'gif'],
  },
  instagram: {
    name: 'Instagram',
    width: 1080,
    height: 1080,
    aspectRatio: '1:1',
    maxSize: 8 * 1024 * 1024,
    formats: ['jpg', 'png'],
  },
  facebook: {
    name: 'Facebook',
    width: 1200,
    height: 630,
    aspectRatio: '1.91:1',
    maxSize: 8 * 1024 * 1024,
    formats: ['jpg', 'png', 'gif'],
  },
};

export const resizeImageForPlatform = (
  imageUrl: string,
  platform: string
): Promise<string> => {
  return new Promise((resolve) => {
    const spec = PLATFORM_SPECS[platform];
    if (!spec) {
      resolve(imageUrl);
      return;
    }

    const img = new Image();
    img.crossOrigin = 'anonymous';

    img.onload = () => {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');

      if (!ctx) {
        resolve(imageUrl);
        return;
      }

      canvas.width = spec.width;
      canvas.height = spec.height;

      const imgAspect = img.width / img.height;
      const targetAspect = spec.width / spec.height;

      let drawWidth = canvas.width;
      let drawHeight = canvas.height;
      let offsetX = 0;
      let offsetY = 0;

      if (imgAspect > targetAspect) {
        drawWidth = canvas.height * imgAspect;
        offsetX = (canvas.width - drawWidth) / 2;
      } else {
        drawHeight = canvas.width / imgAspect;
        offsetY = (canvas.height - drawHeight) / 2;
      }

      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(img, offsetX, offsetY, drawWidth, drawHeight);

      const resizedUrl = canvas.toDataURL('image/jpeg', 0.9);
      resolve(resizedUrl);
    };

    img.onerror = () => {
      resolve(imageUrl);
    };

    img.src = imageUrl;
  });
};

export const generatePlatformVariants = async (
  imageUrl: string,
  selectedPlatforms: string[]
): Promise<Record<string, string>> => {
  const variants: Record<string, string> = {};

  for (const platform of selectedPlatforms) {
    const resized = await resizeImageForPlatform(imageUrl, platform);
    variants[platform] = resized;
  }

  return variants;
};

export const getPlatformRecommendations = (imageWidth: number, imageHeight: number) => {
  const aspectRatio = imageWidth / imageHeight;
  const recommendations: string[] = [];

  Object.entries(PLATFORM_SPECS).forEach(([platform, spec]) => {
    const targetAspect = spec.width / spec.height;
    const diff = Math.abs(aspectRatio - targetAspect);

    if (diff < 0.3) {
      recommendations.push(platform);
    }
  });

  return recommendations.length > 0 ? recommendations : ['twitter', 'facebook'];
};
