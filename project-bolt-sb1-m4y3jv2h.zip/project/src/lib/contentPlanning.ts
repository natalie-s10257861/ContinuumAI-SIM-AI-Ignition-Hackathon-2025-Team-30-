export interface ContentTheme {
  name: string;
  description: string;
  suggestedDays: number[];
  hashtags: string[];
}

export interface SuggestedPost {
  title: string;
  content: string;
  theme: string;
  suggestedDate: string;
  platforms: string[];
}

export const generateContentPlan = async (
  brandVoice: string,
  contentPillars: string[],
  month: number,
  year: number
): Promise<{ themes: ContentTheme[]; suggestedPosts: SuggestedPost[] }> => {
  await new Promise(resolve => setTimeout(resolve, 1000));

  const monthName = new Date(year, month - 1).toLocaleDateString('en-US', { month: 'long' });

  const defaultThemes: ContentTheme[] = [
    {
      name: 'Product Updates',
      description: 'Share new features, improvements, and product announcements',
      suggestedDays: [5, 15, 25],
      hashtags: ['#ProductUpdate', '#Innovation', '#NewFeature'],
    },
    {
      name: 'Behind the Scenes',
      description: 'Show your team, culture, and company values',
      suggestedDays: [10, 20],
      hashtags: ['#TeamWork', '#CompanyCulture', '#BehindTheScenes'],
    },
    {
      name: 'Customer Success',
      description: 'Highlight customer wins, testimonials, and case studies',
      suggestedDays: [8, 18, 28],
      hashtags: ['#CustomerSuccess', '#Testimonial', '#CaseStudy'],
    },
    {
      name: 'Industry Insights',
      description: 'Share thought leadership and industry trends',
      suggestedDays: [3, 13, 23],
      hashtags: ['#ThoughtLeadership', '#IndustryTrends', '#Insights'],
    },
  ];

  const themes = contentPillars.length > 0
    ? contentPillars.map((pillar, idx) => ({
        name: pillar,
        description: `Content focused on ${pillar.toLowerCase()}`,
        suggestedDays: [5 + idx * 7, 15 + idx * 7],
        hashtags: [`#${pillar.replace(/\s+/g, '')}`, '#Growth', '#Success'],
      }))
    : defaultThemes;

  const suggestedPosts: SuggestedPost[] = [];

  themes.forEach(theme => {
    theme.suggestedDays.forEach(day => {
      const date = new Date(year, month - 1, day);
      suggestedPosts.push({
        title: `${theme.name} - ${monthName} ${day}`,
        content: `${theme.description}. Perfect timing to share this with your audience!`,
        theme: theme.name,
        suggestedDate: date.toISOString(),
        platforms: ['twitter', 'linkedin', 'instagram', 'facebook'],
      });
    });
  });

  return { themes, suggestedPosts };
};

export const generateHashtags = (
  content: string,
  platform: 'twitter' | 'linkedin' | 'instagram' | 'facebook',
  category?: string
): string[] => {
  const platformLimits = {
    twitter: 2,
    linkedin: 3,
    instagram: 15,
    facebook: 3,
  };

  const genericHashtags = [
    '#Growth',
    '#Innovation',
    '#Business',
    '#Success',
    '#Marketing',
    '#SocialMedia',
    '#Digital',
    '#Tech',
    '#Startup',
    '#Entrepreneur',
  ];

  const categoryHashtags: Record<string, string[]> = {
    product: ['#ProductLaunch', '#NewFeature', '#ProductUpdate', '#Innovation'],
    team: ['#TeamWork', '#CompanyCulture', '#HiringNow', '#TeamSpotlight'],
    customer: ['#CustomerSuccess', '#Testimonial', '#CaseStudy', '#ClientLove'],
    industry: ['#ThoughtLeadership', '#IndustryNews', '#Insights', '#Trends'],
  };

  const selectedHashtags = category && categoryHashtags[category]
    ? [...categoryHashtags[category], ...genericHashtags]
    : genericHashtags;

  const limit = platformLimits[platform];
  return selectedHashtags.slice(0, limit);
};
