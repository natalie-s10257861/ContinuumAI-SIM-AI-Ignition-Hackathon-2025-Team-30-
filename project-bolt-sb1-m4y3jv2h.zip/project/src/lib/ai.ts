export interface GenerateCopyParams {
  prompt: string;
  platform?: 'twitter' | 'linkedin' | 'instagram' | 'facebook';
  brandVoice?: string;
  tone?: 'professional' | 'casual' | 'friendly' | 'authoritative';
}

export const generateAICopy = async (params: GenerateCopyParams): Promise<string> => {
  const { prompt, platform, brandVoice, tone = 'professional' } = params;

  const platformLimits = {
    twitter: 280,
    linkedin: 3000,
    instagram: 2200,
    facebook: 63206,
  };

  const charLimit = platform ? platformLimits[platform] : 1000;

  const systemPrompt = `You are a professional social media copywriter.
${brandVoice ? `Brand voice: ${brandVoice}` : ''}
Tone: ${tone}
${platform ? `Platform: ${platform} (max ${charLimit} characters)` : ''}
Generate engaging, on-brand copy that drives engagement.`;

  await new Promise(resolve => setTimeout(resolve, 800));

  const samples = {
    twitter: [
      `${prompt.slice(0, 50)}... Just launched something exciting! Check it out and let us know what you think. Your feedback matters! 🚀 #Innovation #Growth`,
      `Big news! ${prompt.slice(0, 100)}... This is a game-changer for our community. Who's ready to dive in? 💡`,
      `${prompt.slice(0, 80)}... We've been working on this for months, and it's finally here! Can't wait to share more. Stay tuned! ✨`
    ],
    linkedin: [
      `${prompt}\n\nWe're thrilled to announce this milestone in our journey. This represents months of dedicated work from our team, and we couldn't be more excited to share it with you.\n\nKey highlights:\n• Innovation-driven approach\n• User-centric design\n• Scalable solution\n\nWe'd love to hear your thoughts and feedback. What do you think?\n\n#BusinessGrowth #Innovation #Leadership`,
      `Exciting update: ${prompt}\n\nAt our core, we believe in delivering value and excellence. This latest development embodies those principles and takes us one step closer to our mission.\n\nWant to learn more? Drop a comment or reach out directly. Let's connect!\n\n#ProfessionalDevelopment #Industry #Success`
    ],
    instagram: [
      `${prompt} ✨\n\nWe're so excited to finally share this with you! Swipe to see more and let us know what you think in the comments below. 💙\n\n📸 Tag a friend who needs to see this!\n\n#brandstory #innovation #creative #inspiration #community #trending #instagood #photooftheday`,
      `New drop! ${prompt} 🔥\n\nThis has been in the works for a while, and we can't wait for you to experience it. Head to the link in bio to learn more!\n\n💫 Double tap if you're excited\n💬 Comment your thoughts\n📲 Share with your network\n\n#lifestyle #design #goals #viral #explore #followus`
    ],
    facebook: [
      `We have some exciting news to share! ${prompt}\n\nThis is something we've been passionate about for a long time, and we're thrilled to finally bring it to life. Our team has poured their hearts into making this the best it can be.\n\n🎯 What makes this special:\n- Thoughtfully designed\n- Built for you\n- Ready to make an impact\n\nWe'd love to hear what you think! Drop a comment below or share with someone who'd appreciate this. Thank you for being part of our journey! ❤️\n\n#Community #Innovation #Excellence`,
      `Big announcement! ${prompt}\n\nWe're incredibly proud of what we've accomplished, and we couldn't have done it without the support of this amazing community.\n\nClick the link to learn more and join us on this exciting journey. Don't forget to like, comment, and share!\n\n#Growth #Success #Inspiration`
    ]
  };

  const platformSamples = samples[platform || 'twitter'];
  const generated = platformSamples[Math.floor(Math.random() * platformSamples.length)];

  return generated.slice(0, charLimit);
};

export const optimizeCopyForPlatform = (
  originalContent: string,
  targetPlatform: 'twitter' | 'linkedin' | 'instagram' | 'facebook'
): string => {
  const platformLimits = {
    twitter: 280,
    linkedin: 3000,
    instagram: 2200,
    facebook: 63206,
  };

  let optimized = originalContent;

  if (targetPlatform === 'twitter') {
    optimized = optimized.slice(0, 250);
    if (!optimized.includes('#')) {
      optimized += ' #trending';
    }
  } else if (targetPlatform === 'linkedin') {
    if (!optimized.includes('\n\n')) {
      const words = optimized.split(' ');
      const midPoint = Math.floor(words.length / 2);
      optimized = words.slice(0, midPoint).join(' ') + '\n\n' + words.slice(midPoint).join(' ');
    }
  } else if (targetPlatform === 'instagram') {
    if (!optimized.includes('#')) {
      optimized += '\n\n#instagram #instagood #photooftheday';
    }
  }

  return optimized.slice(0, platformLimits[targetPlatform]);
};
