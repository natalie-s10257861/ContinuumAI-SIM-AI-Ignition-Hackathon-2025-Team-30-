import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type Brand = {
  id: string;
  name: string;
  logo_url: string | null;
  brand_colors: {
    primary: string;
    secondary: string;
    accent: string;
  };
  brand_voice: string | null;
  content_pillars?: string[] | any;
  posting_frequency?: Record<string, number> | any;
  created_at: string;
  user_id: string;
};

export type SocialAccount = {
  id: string;
  brand_id: string;
  platform: 'twitter' | 'linkedin' | 'instagram' | 'facebook';
  account_name: string;
  is_connected: boolean;
  created_at: string;
};

export type ContentPost = {
  id: string;
  brand_id: string;
  title: string;
  content: string;
  scheduled_date: string;
  status: 'draft' | 'scheduled' | 'published' | 'failed';
  requires_approval?: boolean;
  hashtags?: string[] | any;
  created_at: string;
  updated_at: string;
};

export type PostAsset = {
  id: string;
  post_id: string;
  asset_url: string;
  asset_type: 'image' | 'video' | 'gif';
  original_filename: string | null;
  created_at: string;
};

export type PostVariant = {
  id: string;
  post_id: string;
  social_account_id: string;
  platform: 'twitter' | 'linkedin' | 'instagram' | 'facebook';
  content: string;
  asset_url: string | null;
  status: 'pending' | 'published' | 'failed';
  published_at: string | null;
  created_at: string;
};
