import { useState } from 'react';
import { Wand2, Download, Image as ImageIcon, Loader, Sparkles } from 'lucide-react';

interface AIImageGeneratorProps {
  onImageGenerated?: (imageUrl: string) => void;
}

export default function AIImageGenerator({ onImageGenerated }: AIImageGeneratorProps) {
  const [prompt, setPrompt] = useState('');
  const [generatedImages, setGeneratedImages] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectedStyle, setSelectedStyle] = useState<string>('photorealistic');

  const styles = [
    { id: 'photorealistic', name: 'Photorealistic', description: 'Realistic photos' },
    { id: 'digital-art', name: 'Digital Art', description: 'Modern digital artwork' },
    { id: 'illustration', name: 'Illustration', description: 'Hand-drawn style' },
    { id: 'abstract', name: 'Abstract', description: 'Abstract art style' },
    { id: 'minimalist', name: 'Minimalist', description: 'Simple and clean' },
    { id: '3d-render', name: '3D Render', description: '3D graphics' },
  ];

  const examplePrompts = [
    'A modern office workspace with natural lighting',
    'Coffee cup on a wooden table, morning sunlight',
    'Colorful abstract geometric shapes on gradient background',
    'Professional business team collaboration',
    'Laptop with social media icons floating around it',
    'Minimalist product photography on white background',
  ];

  const generateImage = async () => {
    if (!prompt.trim()) {
      alert('Please enter a prompt');
      return;
    }

    setLoading(true);
    try {
      const fullPrompt = `${prompt}, ${selectedStyle} style`;

      const images = await Promise.all([
        generatePlaceholderImage(fullPrompt, 1),
        generatePlaceholderImage(fullPrompt, 2),
        generatePlaceholderImage(fullPrompt, 3),
      ]);

      setGeneratedImages(images);
    } catch (error) {
      console.error('Error generating images:', error);
      alert('Failed to generate images. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const generatePlaceholderImage = async (prompt: string, seed: number): Promise<string> => {
    await new Promise(resolve => setTimeout(resolve, 2000));

    const width = 1024;
    const height = 1024;
    const text = encodeURIComponent(prompt.slice(0, 50));

    return `https://images.unsplash.com/photo-${1580000000000 + seed * 100000000}?w=${width}&h=${height}&fit=crop&q=80`;
  };

  const handleUseImage = (imageUrl: string) => {
    if (onImageGenerated) {
      onImageGenerated(imageUrl);
    }
  };

  const handleDownload = async (imageUrl: string) => {
    try {
      const response = await fetch(imageUrl);
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `ai-generated-${Date.now()}.jpg`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Error downloading image:', error);
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
      <div className="flex items-center gap-3 mb-6">
        <div className="p-2 bg-gradient-to-br from-purple-500 to-pink-600 rounded-lg">
          <Sparkles className="w-5 h-5 text-white" />
        </div>
        <div>
          <h3 className="text-lg font-semibold text-gray-900">AI Image Generator</h3>
          <p className="text-sm text-gray-600">Create stunning images from text prompts</p>
        </div>
      </div>

      <div className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Describe Your Image
          </label>
          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="E.g., A beautiful sunset over mountains with vibrant colors..."
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent outline-none transition resize-none"
            rows={4}
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-3">
            Art Style
          </label>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            {styles.map((style) => (
              <button
                key={style.id}
                onClick={() => setSelectedStyle(style.id)}
                className={`p-3 rounded-lg border-2 transition text-left ${
                  selectedStyle === style.id
                    ? 'border-purple-500 bg-purple-50'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                <div className="font-medium text-gray-900 text-sm">{style.name}</div>
                <div className="text-xs text-gray-600">{style.description}</div>
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Try These Prompts
          </label>
          <div className="flex flex-wrap gap-2">
            {examplePrompts.map((example, idx) => (
              <button
                key={idx}
                onClick={() => setPrompt(example)}
                className="text-xs px-3 py-1.5 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-full transition"
              >
                {example}
              </button>
            ))}
          </div>
        </div>

        <button
          onClick={generateImage}
          disabled={loading || !prompt.trim()}
          className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white font-medium py-3 px-4 rounded-lg transition disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
        >
          {loading ? (
            <>
              <Loader className="w-5 h-5 animate-spin" />
              Generating Images...
            </>
          ) : (
            <>
              <Wand2 className="w-5 h-5" />
              Generate Images
            </>
          )}
        </button>

        {generatedImages.length > 0 && (
          <div className="space-y-4 pt-4 border-t border-gray-200">
            <h4 className="text-sm font-semibold text-gray-900">Generated Images</h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {generatedImages.map((imageUrl, idx) => (
                <div
                  key={idx}
                  className="relative group rounded-lg overflow-hidden border-2 border-gray-200 hover:border-purple-400 transition"
                >
                  <img
                    src={imageUrl}
                    alt={`Generated ${idx + 1}`}
                    className="w-full aspect-square object-cover"
                  />
                  <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-40 transition flex items-center justify-center gap-2">
                    <button
                      onClick={() => handleUseImage(imageUrl)}
                      className="opacity-0 group-hover:opacity-100 transition px-4 py-2 bg-white hover:bg-gray-100 text-gray-900 rounded-lg font-medium text-sm flex items-center gap-2"
                    >
                      <ImageIcon className="w-4 h-4" />
                      Use Image
                    </button>
                    <button
                      onClick={() => handleDownload(imageUrl)}
                      className="opacity-0 group-hover:opacity-100 transition p-2 bg-white hover:bg-gray-100 text-gray-900 rounded-lg"
                    >
                      <Download className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {generatedImages.length > 0 && (
          <button
            onClick={() => setGeneratedImages([])}
            className="w-full px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-lg transition text-sm font-medium"
          >
            Clear Results
          </button>
        )}
      </div>

      <div className="mt-6 p-4 bg-violet-50 border border-violet-200 rounded-lg">
        <p className="text-sm text-violet-900">
          <strong>Demo Mode:</strong> This AI image generator uses Unsplash stock photos as placeholders.
          To generate real AI images, integrate with services like DALL-E, Midjourney, or Stable Diffusion APIs.
        </p>
      </div>
    </div>
  );
}
