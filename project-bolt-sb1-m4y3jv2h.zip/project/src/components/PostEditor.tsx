import { useState, useEffect } from 'react';
import { X, Calendar, Image as ImageIcon, Wand2, Save, Hash, CheckCircle, Crop } from 'lucide-react';
import { ContentPost, supabase, SocialAccount } from '../lib/supabase';
import { generateHashtags } from '../lib/contentPlanning';
import { generatePlatformVariants } from '../lib/assetOptimization';
import AICopywriter from './AICopywriter';
import PlatformSelector from './PlatformSelector';
import ImageCropEditor from './ImageCropEditor';

interface PostEditorProps {
  post?: ContentPost;
  brandId: string;
  brandVoice?: string;
  accounts: SocialAccount[];
  onClose: () => void;
  onSave: () => void;
}

export default function PostEditor({ post, brandId, brandVoice, accounts, onClose, onSave }: PostEditorProps) {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [scheduledDate, setScheduledDate] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [hashtags, setHashtags] = useState<string[]>([]);
  const [selectedAccounts, setSelectedAccounts] = useState<string[]>([]);
  const [showAI, setShowAI] = useState(false);
  const [saving, setSaving] = useState(false);
  const [imageSize, setImageSize] = useState<'original' | 'square' | 'landscape' | 'portrait'>('original');
  const [showCropEditor, setShowCropEditor] = useState(false);
  const [cropPlatform, setCropPlatform] = useState<string>('Custom');

  useEffect(() => {
    if (post) {
      setTitle(post.title);
      setContent(post.content);
      setScheduledDate(post.scheduled_date.slice(0, 16));
      if (post.hashtags && Array.isArray(post.hashtags)) {
        setHashtags(post.hashtags as string[]);
      }
      if (post.media_url) {
        setImageUrl(post.media_url);
      }
    } else {
      const tomorrow = new Date();
      tomorrow.setDate(tomorrow.getDate() + 1);
      tomorrow.setHours(12, 0, 0, 0);
      setScheduledDate(tomorrow.toISOString().slice(0, 16));
    }
  }, [post]);

  const handleGenerateHashtags = () => {
    const generated = generateHashtags(content, 'instagram');
    setHashtags(generated);
  };

  const handleToggleAccount = (accountId: string) => {
    setSelectedAccounts(prev =>
      prev.includes(accountId)
        ? prev.filter(id => id !== accountId)
        : [...prev, accountId]
    );
  };

  const handleSave = async (status: 'draft' | 'scheduled') => {
    if (!title.trim() || !content.trim()) return;

    setSaving(true);
    try {
      const postData = {
        brand_id: brandId,
        title: title.trim(),
        content: content.trim(),
        scheduled_date: new Date(scheduledDate).toISOString(),
        status,
        hashtags: hashtags,
        requires_approval: status === 'scheduled',
        media_url: imageUrl || null,
      };

      let postId: string;

      if (post) {
        await supabase
          .from('content_posts')
          .update({ ...postData, updated_at: new Date().toISOString() })
          .eq('id', post.id);
        postId = post.id;
      } else {
        const { data: newPost, error } = await supabase
          .from('content_posts')
          .insert([postData])
          .select()
          .single();

        if (error) throw error;
        postId = newPost.id;

        if (imageUrl && newPost) {
          await supabase.from('post_assets').insert([
            {
              post_id: newPost.id,
              asset_url: imageUrl,
              asset_type: 'image',
            },
          ]);
        }
      }

      if (selectedAccounts.length > 0 && imageUrl) {
        const selectedPlatforms = selectedAccounts.map(
          accId => accounts.find(a => a.id === accId)?.platform
        ).filter(Boolean) as string[];

        const variants = await generatePlatformVariants(imageUrl, selectedPlatforms);

        const variantData = selectedAccounts.map(accountId => {
          const account = accounts.find(a => a.id === accountId);
          return {
            post_id: postId,
            social_account_id: accountId,
            platform: account!.platform,
            content: content.trim() + (hashtags.length > 0 ? '\n\n' + hashtags.join(' ') : ''),
            asset_url: variants[account!.platform] || imageUrl,
            status: 'pending',
          };
        });

        await supabase.from('post_variants').insert(variantData);
      }

      if (status === 'scheduled') {
        await supabase.from('post_approvals').insert([
          {
            post_id: postId,
            status: 'pending',
          },
        ]);
      }

      onSave();
      onClose();
    } catch (error) {
      console.error('Error saving post:', error);
    } finally {
      setSaving(false);
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImageUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };


  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden flex flex-col">
        <div className="p-6 border-b border-gray-200 flex items-center justify-between">
          <h2 className="text-2xl font-bold text-gray-900">
            {post ? 'Edit Post' : 'Create New Post'}
          </h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition"
          >
            <X className="w-6 h-6 text-gray-600" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Post Title
                </label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="Give your post a title..."
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-violet-500 focus:border-transparent outline-none transition"
                />
              </div>

              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="block text-sm font-medium text-gray-700">
                    Content
                  </label>
                  <button
                    onClick={() => setShowAI(!showAI)}
                    className="text-sm text-violet-600 hover:text-violet-700 font-medium flex items-center gap-1"
                  >
                    <Wand2 className="w-4 h-4" />
                    {showAI ? 'Hide' : 'AI Copywriter'}
                  </button>
                </div>
                <textarea
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  placeholder="Write your post content or use AI to generate it..."
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-violet-500 focus:border-transparent outline-none resize-none transition"
                  rows={8}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Schedule Date & Time
                </label>
                <div className="relative">
                  <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="datetime-local"
                    value={scheduledDate}
                    onChange={(e) => setScheduledDate(e.target.value)}
                    className="w-full pl-11 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-violet-500 focus:border-transparent outline-none transition"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Image
                </label>
                {imageUrl ? (
                  <div className="space-y-3">
                    <div className="relative">
                      <img
                        src={imageUrl}
                        alt="Post"
                        className={`w-full rounded-lg ${
                          imageSize === 'square' ? 'aspect-square object-cover' :
                          imageSize === 'landscape' ? 'aspect-video object-cover' :
                          imageSize === 'portrait' ? 'aspect-[3/4] object-cover' :
                          'h-48 object-cover'
                        }`}
                      />
                      <button
                        onClick={() => setImageUrl('')}
                        className="absolute top-2 right-2 bg-red-600 hover:bg-red-700 text-white px-3 py-1 rounded-lg font-medium text-sm"
                      >
                        Remove
                      </button>
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-gray-600 mb-2">
                        Resize for Platform
                      </label>
                      <div className="grid grid-cols-4 gap-2">
                        <button
                          onClick={() => setImageSize('original')}
                          className={`px-3 py-2 text-xs rounded-lg border transition ${
                            imageSize === 'original'
                              ? 'bg-violet-100 border-violet-500 text-violet-700'
                              : 'bg-white border-gray-300 text-gray-700 hover:border-gray-400'
                          }`}
                        >
                          Original
                        </button>
                        <button
                          onClick={() => setImageSize('square')}
                          className={`px-3 py-2 text-xs rounded-lg border transition ${
                            imageSize === 'square'
                              ? 'bg-violet-100 border-violet-500 text-violet-700'
                              : 'bg-white border-gray-300 text-gray-700 hover:border-gray-400'
                          }`}
                        >
                          Square
                        </button>
                        <button
                          onClick={() => setImageSize('landscape')}
                          className={`px-3 py-2 text-xs rounded-lg border transition ${
                            imageSize === 'landscape'
                              ? 'bg-violet-100 border-violet-500 text-violet-700'
                              : 'bg-white border-gray-300 text-gray-700 hover:border-gray-400'
                          }`}
                        >
                          Landscape
                        </button>
                        <button
                          onClick={() => setImageSize('portrait')}
                          className={`px-3 py-2 text-xs rounded-lg border transition ${
                            imageSize === 'portrait'
                              ? 'bg-violet-100 border-violet-500 text-violet-700'
                              : 'bg-white border-gray-300 text-gray-700 hover:border-gray-400'
                          }`}
                        >
                          Portrait
                        </button>
                      </div>
                      <p className="text-xs text-gray-500 mt-2">
                        {imageSize === 'square' && '1:1 - Best for Instagram'}
                        {imageSize === 'landscape' && '16:9 - Best for LinkedIn/Facebook'}
                        {imageSize === 'portrait' && '3:4 - Best for Stories'}
                        {imageSize === 'original' && 'Original dimensions'}
                      </p>
                    </div>
                    <button
                      onClick={() => {
                        setCropPlatform(
                          imageSize === 'square' ? 'Instagram (1:1)' :
                          imageSize === 'landscape' ? 'LinkedIn/Facebook (16:9)' :
                          imageSize === 'portrait' ? 'Stories (3:4)' :
                          'Custom'
                        );
                        setShowCropEditor(true);
                      }}
                      className="w-full bg-violet-600 hover:bg-violet-700 text-white font-medium py-2 px-4 rounded-lg transition flex items-center justify-center gap-2"
                    >
                      <Crop className="w-4 h-4" />
                      Manual Crop & Resize
                    </button>
                  </div>
                ) : (
                  <label className="flex flex-col items-center justify-center w-full h-48 border-2 border-dashed border-gray-300 rounded-lg cursor-pointer hover:border-violet-500 transition">
                    <ImageIcon className="w-12 h-12 text-gray-400 mb-2" />
                    <span className="text-sm text-gray-600">Click to upload image</span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleImageUpload}
                      className="hidden"
                    />
                  </label>
                )}
              </div>

              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="block text-sm font-medium text-gray-700">
                    Hashtags
                  </label>
                  <button
                    onClick={handleGenerateHashtags}
                    className="text-sm text-violet-600 hover:text-violet-700 font-medium flex items-center gap-1"
                  >
                    <Hash className="w-4 h-4" />
                    Generate
                  </button>
                </div>
                <div className="flex flex-wrap gap-2 p-3 bg-gray-50 rounded-lg border border-gray-200 min-h-[60px]">
                  {hashtags.length > 0 ? (
                    hashtags.map((tag, idx) => (
                      <span
                        key={idx}
                        className="px-3 py-1 bg-violet-100 text-violet-700 rounded-full text-sm flex items-center gap-2"
                      >
                        {tag}
                        <button
                          onClick={() => setHashtags(hashtags.filter((_, i) => i !== idx))}
                          className="hover:text-violet-900"
                        >
                          ×
                        </button>
                      </span>
                    ))
                  ) : (
                    <span className="text-sm text-gray-500">No hashtags yet</span>
                  )}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Select Platforms
                </label>
                <PlatformSelector
                  accounts={accounts}
                  selectedAccounts={selectedAccounts}
                  onToggleAccount={handleToggleAccount}
                />
              </div>

            </div>

            <div>
              {showAI && (
                <AICopywriter
                  brandVoice={brandVoice}
                  onCopyGenerated={(generatedContent) => {
                    setContent(generatedContent);
                    setShowAI(false);
                  }}
                />
              )}
            </div>
          </div>
        </div>

        <div className="p-6 border-t border-gray-200 flex items-center justify-end gap-3">
          <button
            onClick={onClose}
            className="px-6 py-2.5 text-gray-700 hover:bg-gray-100 rounded-lg font-medium transition"
          >
            Cancel
          </button>
          <button
            onClick={() => handleSave('draft')}
            disabled={saving || !title.trim() || !content.trim()}
            className="px-6 py-2.5 bg-gray-600 hover:bg-gray-700 text-white rounded-lg font-medium transition disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
          >
            <Save className="w-4 h-4" />
            Save Draft
          </button>
          <button
            onClick={() => handleSave('scheduled')}
            disabled={saving || !title.trim() || !content.trim() || selectedAccounts.length === 0}
            className="px-6 py-2.5 bg-violet-600 hover:bg-violet-700 text-white rounded-lg font-medium transition disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
          >
            <CheckCircle className="w-4 h-4" />
            {saving ? 'Scheduling...' : 'Confirm & Schedule'}
          </button>
        </div>
      </div>

      {showCropEditor && imageUrl && (
        <ImageCropEditor
          imageUrl={imageUrl}
          aspectRatio={
            imageSize === 'square' ? 1 :
            imageSize === 'landscape' ? 16/9 :
            imageSize === 'portrait' ? 3/4 :
            undefined
          }
          platformName={cropPlatform}
          onCropComplete={(croppedUrl) => {
            setImageUrl(croppedUrl);
            setShowCropEditor(false);
          }}
          onCancel={() => setShowCropEditor(false)}
        />
      )}
    </div>
  );
}
