import { useState, useEffect } from 'react';
import { Calendar, ChevronLeft, ChevronRight, Trash2 } from 'lucide-react';
import { ContentPost } from '../lib/supabase';

interface CalendarViewProps {
  posts: ContentPost[];
  onDateClick: (date: Date) => void;
  onPostClick: (post: ContentPost) => void;
  onDeletePost: (post: ContentPost) => void;
}

export default function CalendarView({ posts, onDateClick, onPostClick, onDeletePost }: CalendarViewProps) {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [calendarDays, setCalendarDays] = useState<Date[]>([]);

  useEffect(() => {
    generateCalendarDays();
  }, [currentDate]);

  const generateCalendarDays = () => {
    const year = currentDate.getFullYear();
    const month = currentDate.getMonth();

    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);

    const startDate = new Date(firstDay);
    startDate.setDate(startDate.getDate() - startDate.getDay());

    const days: Date[] = [];
    const currentDay = new Date(startDate);

    for (let i = 0; i < 42; i++) {
      days.push(new Date(currentDay));
      currentDay.setDate(currentDay.getDate() + 1);
    }

    setCalendarDays(days);
  };

  const previousMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1));
  };

  const nextMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1));
  };

  const getPostsForDate = (date: Date) => {
    return posts.filter(post => {
      const postDate = new Date(post.scheduled_date);
      return postDate.toDateString() === date.toDateString();
    });
  };

  const isToday = (date: Date) => {
    const today = new Date();
    return date.toDateString() === today.toDateString();
  };

  const isCurrentMonth = (date: Date) => {
    return date.getMonth() === currentDate.getMonth();
  };

  const monthYear = currentDate.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
      <div className="p-6 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Calendar className="w-6 h-6 text-violet-600" />
            <h2 className="text-xl font-semibold text-gray-900">{monthYear}</h2>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={previousMonth}
              className="p-2 hover:bg-gray-100 rounded-lg transition"
            >
              <ChevronLeft className="w-5 h-5 text-gray-600" />
            </button>
            <button
              onClick={nextMonth}
              className="p-2 hover:bg-gray-100 rounded-lg transition"
            >
              <ChevronRight className="w-5 h-5 text-gray-600" />
            </button>
          </div>
        </div>
      </div>

      <div className="p-4">
        <div className="grid grid-cols-7 gap-2 mb-2">
          {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
            <div key={day} className="text-center text-sm font-medium text-gray-600 py-2">
              {day}
            </div>
          ))}
        </div>

        <div className="grid grid-cols-7 gap-2">
          {calendarDays.map((date, index) => {
            const dayPosts = getPostsForDate(date);
            const isTodayDate = isToday(date);
            const isCurrentMonthDate = isCurrentMonth(date);

            return (
              <div
                key={index}
                onClick={() => onDateClick(date)}
                className={`
                  min-h-24 p-2 border rounded-lg cursor-pointer transition
                  ${isTodayDate ? 'border-violet-500 bg-violet-50' : 'border-gray-200 hover:border-gray-300'}
                  ${!isCurrentMonthDate ? 'opacity-40' : ''}
                `}
              >
                <div className={`text-sm font-medium mb-1 ${isTodayDate ? 'text-violet-600' : 'text-gray-700'}`}>
                  {date.getDate()}
                </div>
                <div className="space-y-1">
                  {dayPosts.slice(0, 3).map(post => {
                    const needsApproval = post.requires_approval && post.status === 'scheduled';
                    return (
                      <div
                        key={post.id}
                        className={`
                          text-xs px-2 py-1 rounded cursor-pointer group relative
                          ${post.status === 'published' ? 'bg-green-100 text-green-700' : ''}
                          ${post.status === 'scheduled' ? (needsApproval ? 'bg-orange-100 text-orange-700 border border-orange-300' : 'bg-violet-100 text-violet-700') : ''}
                          ${post.status === 'draft' ? 'bg-gray-100 text-gray-700' : ''}
                          ${post.status === 'failed' ? 'bg-red-100 text-red-700' : ''}
                          hover:opacity-80 transition flex items-center gap-1 justify-between
                        `}
                      >
                        <div
                          onClick={(e) => {
                            e.stopPropagation();
                            onPostClick(post);
                          }}
                          className="flex items-center gap-1 flex-1 truncate"
                        >
                          {needsApproval && <span className="text-orange-600">⚠</span>}
                          <span className="truncate">{post.title}</span>
                        </div>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            if (confirm(`Delete "${post.title}"?`)) {
                              onDeletePost(post);
                            }
                          }}
                          className="opacity-0 group-hover:opacity-100 transition p-0.5 hover:bg-red-200 rounded"
                          title="Delete post"
                        >
                          <Trash2 className="w-3 h-3 text-red-600" />
                        </button>
                      </div>
                    );
                  })}
                  {dayPosts.length > 3 && (
                    <div className="text-xs text-gray-500 px-2">
                      +{dayPosts.length - 3} more
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
