import { useState, useRef, useEffect } from 'react';
import { Crop, X, Check, RotateCw } from 'lucide-react';

interface ImageCropEditorProps {
  imageUrl: string;
  aspectRatio?: number;
  onCropComplete: (croppedImageUrl: string) => void;
  onCancel: () => void;
  platformName?: string;
}

interface CropArea {
  x: number;
  y: number;
  width: number;
  height: number;
}

export default function ImageCropEditor({
  imageUrl,
  aspectRatio,
  onCropComplete,
  onCancel,
  platformName = 'Custom'
}: ImageCropEditorProps) {
  const [crop, setCrop] = useState<CropArea>({ x: 0, y: 0, width: 100, height: 100 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragHandle, setDragHandle] = useState<string | null>(null);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const [imageSize, setImageSize] = useState({ width: 0, height: 0 });
  const [rotation, setRotation] = useState(0);
  const imageRef = useRef<HTMLImageElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const img = new Image();
    img.onload = () => {
      setImageSize({ width: img.width, height: img.height });

      if (aspectRatio) {
        const containerWidth = 400;
        const containerHeight = 400;
        const imgAspect = img.width / img.height;

        let cropWidth = 80;
        let cropHeight = 80;

        if (aspectRatio > imgAspect) {
          cropHeight = cropWidth / aspectRatio;
        } else {
          cropWidth = cropHeight * aspectRatio;
        }

        setCrop({
          x: (100 - cropWidth) / 2,
          y: (100 - cropHeight) / 2,
          width: cropWidth,
          height: cropHeight
        });
      }
    };
    img.src = imageUrl;
  }, [imageUrl, aspectRatio]);

  const handleMouseDown = (e: React.MouseEvent, handle: string) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
    setDragHandle(handle);
    setDragStart({ x: e.clientX, y: e.clientY });
  };

  const handleMouseMove = (e: MouseEvent) => {
    if (!isDragging || !containerRef.current) return;

    const rect = containerRef.current.getBoundingClientRect();
    const deltaX = ((e.clientX - dragStart.x) / rect.width) * 100;
    const deltaY = ((e.clientY - dragStart.y) / rect.height) * 100;

    setCrop(prev => {
      let newCrop = { ...prev };

      if (dragHandle === 'move') {
        newCrop.x = Math.max(0, Math.min(100 - prev.width, prev.x + deltaX));
        newCrop.y = Math.max(0, Math.min(100 - prev.height, prev.y + deltaY));
      } else if (dragHandle === 'nw') {
        const newX = Math.max(0, Math.min(prev.x + prev.width - 10, prev.x + deltaX));
        const newY = Math.max(0, Math.min(prev.y + prev.height - 10, prev.y + deltaY));
        newCrop.width = prev.width + (prev.x - newX);
        newCrop.height = prev.height + (prev.y - newY);
        newCrop.x = newX;
        newCrop.y = newY;

        if (aspectRatio) {
          newCrop.height = newCrop.width / aspectRatio;
        }
      } else if (dragHandle === 'ne') {
        const newY = Math.max(0, Math.min(prev.y + prev.height - 10, prev.y + deltaY));
        newCrop.width = Math.min(100 - prev.x, prev.width + deltaX);
        newCrop.height = prev.height + (prev.y - newY);
        newCrop.y = newY;

        if (aspectRatio) {
          newCrop.height = newCrop.width / aspectRatio;
        }
      } else if (dragHandle === 'sw') {
        const newX = Math.max(0, Math.min(prev.x + prev.width - 10, prev.x + deltaX));
        newCrop.width = prev.width + (prev.x - newX);
        newCrop.height = Math.min(100 - prev.y, prev.height + deltaY);
        newCrop.x = newX;

        if (aspectRatio) {
          newCrop.height = newCrop.width / aspectRatio;
        }
      } else if (dragHandle === 'se') {
        newCrop.width = Math.min(100 - prev.x, prev.width + deltaX);
        newCrop.height = Math.min(100 - prev.y, prev.height + deltaY);

        if (aspectRatio) {
          newCrop.height = newCrop.width / aspectRatio;
        }
      }

      newCrop.width = Math.max(10, Math.min(100 - newCrop.x, newCrop.width));
      newCrop.height = Math.max(10, Math.min(100 - newCrop.y, newCrop.height));

      return newCrop;
    });

    setDragStart({ x: e.clientX, y: e.clientY });
  };

  const handleMouseUp = () => {
    setIsDragging(false);
    setDragHandle(null);
  };

  useEffect(() => {
    if (isDragging) {
      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('mouseup', handleMouseUp);
      return () => {
        window.removeEventListener('mousemove', handleMouseMove);
        window.removeEventListener('mouseup', handleMouseUp);
      };
    }
  }, [isDragging, dragStart, crop]);

  const handleCropComplete = async () => {
    if (!imageRef.current || !containerRef.current) return;

    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const img = new Image();
    img.crossOrigin = 'anonymous';

    img.onload = () => {
      const scaleX = img.width / 100;
      const scaleY = img.height / 100;

      const cropX = crop.x * scaleX;
      const cropY = crop.y * scaleY;
      const cropWidth = crop.width * scaleX;
      const cropHeight = crop.height * scaleY;

      if (rotation !== 0) {
        const angle = (rotation * Math.PI) / 180;
        const cos = Math.cos(angle);
        const sin = Math.sin(angle);

        canvas.width = Math.abs(cropWidth * cos) + Math.abs(cropHeight * sin);
        canvas.height = Math.abs(cropWidth * sin) + Math.abs(cropHeight * cos);

        ctx.translate(canvas.width / 2, canvas.height / 2);
        ctx.rotate(angle);
        ctx.drawImage(
          img,
          cropX, cropY, cropWidth, cropHeight,
          -cropWidth / 2, -cropHeight / 2, cropWidth, cropHeight
        );
      } else {
        canvas.width = cropWidth;
        canvas.height = cropHeight;
        ctx.drawImage(img, cropX, cropY, cropWidth, cropHeight, 0, 0, cropWidth, cropHeight);
      }

      canvas.toBlob((blob) => {
        if (blob) {
          const croppedUrl = URL.createObjectURL(blob);
          onCropComplete(croppedUrl);
        }
      }, 'image/jpeg', 0.95);
    };

    img.src = imageUrl;
  };

  const handleRotate = () => {
    setRotation((prev) => (prev + 90) % 360);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-90 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden flex flex-col">
        <div className="p-4 border-b border-gray-200 flex items-center justify-between">
          <div>
            <h3 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
              <Crop className="w-5 h-5" />
              Crop & Resize Image
            </h3>
            <p className="text-sm text-gray-600">
              {platformName} {aspectRatio ? `(${aspectRatio.toFixed(2)}:1 ratio)` : ''}
            </p>
          </div>
          <button
            onClick={onCancel}
            className="p-2 hover:bg-gray-100 rounded-lg transition"
          >
            <X className="w-5 h-5 text-gray-600" />
          </button>
        </div>

        <div className="flex-1 overflow-auto p-6 bg-gray-50">
          <div className="flex justify-center items-center min-h-full">
            <div
              ref={containerRef}
              className="relative bg-gray-900 rounded-lg overflow-hidden"
              style={{
                width: '600px',
                height: '600px',
                maxWidth: '100%',
                maxHeight: '100%'
              }}
            >
              <img
                ref={imageRef}
                src={imageUrl}
                alt="Crop preview"
                className="w-full h-full object-contain"
                style={{ transform: `rotate(${rotation}deg)` }}
              />

              <div
                className="absolute border-2 border-white shadow-lg cursor-move"
                style={{
                  left: `${crop.x}%`,
                  top: `${crop.y}%`,
                  width: `${crop.width}%`,
                  height: `${crop.height}%`,
                  boxShadow: '0 0 0 9999px rgba(0, 0, 0, 0.5)'
                }}
                onMouseDown={(e) => handleMouseDown(e, 'move')}
              >
                <div
                  className="absolute w-3 h-3 bg-white border-2 border-violet-500 rounded-full cursor-nw-resize"
                  style={{ left: '-6px', top: '-6px' }}
                  onMouseDown={(e) => handleMouseDown(e, 'nw')}
                />
                <div
                  className="absolute w-3 h-3 bg-white border-2 border-violet-500 rounded-full cursor-ne-resize"
                  style={{ right: '-6px', top: '-6px' }}
                  onMouseDown={(e) => handleMouseDown(e, 'ne')}
                />
                <div
                  className="absolute w-3 h-3 bg-white border-2 border-violet-500 rounded-full cursor-sw-resize"
                  style={{ left: '-6px', bottom: '-6px' }}
                  onMouseDown={(e) => handleMouseDown(e, 'sw')}
                />
                <div
                  className="absolute w-3 h-3 bg-white border-2 border-violet-500 rounded-full cursor-se-resize"
                  style={{ right: '-6px', bottom: '-6px' }}
                  onMouseDown={(e) => handleMouseDown(e, 'se')}
                />
              </div>
            </div>
          </div>
        </div>

        <div className="p-4 border-t border-gray-200 flex items-center justify-between gap-3">
          <button
            onClick={handleRotate}
            className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 font-medium rounded-lg transition flex items-center gap-2"
          >
            <RotateCw className="w-4 h-4" />
            Rotate
          </button>

          <div className="flex gap-3">
            <button
              onClick={onCancel}
              className="px-6 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 font-medium rounded-lg transition"
            >
              Cancel
            </button>
            <button
              onClick={handleCropComplete}
              className="px-6 py-2 bg-violet-600 hover:bg-violet-700 text-white font-medium rounded-lg transition flex items-center gap-2"
            >
              <Check className="w-4 h-4" />
              Apply Crop
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
