import { useState, useEffect } from 'react';
import { Plus, LogOut, Settings, BarChart3, Sparkles, Zap, TrendingUp, Bot } from 'lucide-react';
import { supabase, Brand, ContentPost, SocialAccount } from '../lib/supabase';
import CalendarView from './CalendarView';
import PostEditor from './PostEditor';
import BrandSetup from './BrandSetup';
import AIImageGenerator from './AIImageGenerator';
import ApprovalWorkflow from './ApprovalWorkflow';
import AIAssistantChat from './AIAssistantChat';
import PublishModal from './PublishModal';

export default function Dashboard() {
  const [brand, setBrand] = useState<Brand | null>(null);
  const [posts, setPosts] = useState<ContentPost[]>([]);
  const [accounts, setAccounts] = useState<SocialAccount[]>([]);
  const [showPostEditor, setShowPostEditor] = useState(false);
  const [selectedPost, setSelectedPost] = useState<ContentPost | null>(null);
  const [showBrandSetup, setShowBrandSetup] = useState(false);
  const [showAIImageGen, setShowAIImageGen] = useState(false);
  const [showApproval, setShowApproval] = useState(false);
  const [showAIChat, setShowAIChat] = useState(false);
  const [showPublishModal, setShowPublishModal] = useState(false);
  const [pendingApprovalPost, setPendingApprovalPost] = useState<ContentPost | null>(null);
  const [loading, setLoading] = useState(true);
  const [userEmail, setUserEmail] = useState<string>('');

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const { data: userData } = await supabase.auth.getUser();
      if (!userData.user) return;

      setUserEmail(userData.user.email || '');

      const { data: brandData } = await supabase
        .from('brands')
        .select('*')
        .eq('user_id', userData.user.id)
        .single();

      if (brandData) {
        setBrand(brandData);
        await loadPosts(brandData.id);
        await loadAccounts(brandData.id);
      } else {
        setShowBrandSetup(true);
      }
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadPosts = async (brandId: string) => {
    const { data } = await supabase
      .from('content_posts')
      .select('*')
      .eq('brand_id', brandId)
      .order('scheduled_date', { ascending: true });

    if (data) setPosts(data);
  };

  const loadAccounts = async (brandId: string) => {
    const { data } = await supabase
      .from('social_accounts')
      .select('*')
      .eq('brand_id', brandId);

    if (data) setAccounts(data);
  };

  const handleSignOut = async () => {
    await supabase.auth.signOut();
    window.location.reload();
  };

  const handleDateClick = (date: Date) => {
    setSelectedPost(null);
    setShowPostEditor(true);
  };

  const handlePostClick = (post: ContentPost) => {
    if (post.requires_approval && post.status === 'scheduled') {
      setPendingApprovalPost(post);
      setShowApproval(true);
    } else {
      setSelectedPost(post);
      setShowPostEditor(true);
    }
  };

  const handleImageGenerated = (imageUrl: string) => {
    console.log('Image generated:', imageUrl);
  };

  const handlePublishClick = () => {
    setShowPublishModal(true);
  };

  const handleDeletePost = async (post: ContentPost) => {
    try {
      await supabase.from('content_posts').delete().eq('id', post.id);
      if (brand) {
        loadPosts(brand.id);
      }
    } catch (error) {
      console.error('Error deleting post:', error);
    }
  };


  const handleBrandSaved = () => {
    setShowBrandSetup(false);
    loadData();
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-gray-600">Loading...</div>
      </div>
    );
  }

  if (showBrandSetup || !brand) {
    return <BrandSetup onSave={handleBrandSaved} />;
  }

  const upcomingPosts = posts.filter(p => new Date(p.scheduled_date) > new Date()).length;
  const publishedPosts = posts.filter(p => p.status === 'published').length;
  const pendingApprovals = posts.filter(p => p.requires_approval && p.status === 'scheduled').length;

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white border-b border-gray-200 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <h1 className="text-2xl font-bold text-gray-900">ContiniumAi</h1>
              {userEmail && (
                <div className="px-3 py-1.5 bg-violet-50 text-violet-700 text-sm font-medium rounded-lg border border-violet-200">
                  {userEmail}
                </div>
              )}
            </div>
            <div className="flex items-center gap-3">
              <button
                onClick={() => setShowAIChat(!showAIChat)}
                className="p-2 hover:bg-gray-100 rounded-lg transition relative"
                title="AI Assistant"
              >
                <Bot className="w-5 h-5 text-gray-600" />
                {showAIChat && (
                  <span className="absolute top-0 right-0 w-2 h-2 bg-green-500 rounded-full" />
                )}
              </button>
              <button
                onClick={handlePublishClick}
                className="px-3 py-1.5 bg-green-600 hover:bg-green-700 text-white text-sm rounded-lg transition"
                title="Publish Now"
              >
                Publish Ready Posts
              </button>
              <button
                onClick={() => setShowBrandSetup(true)}
                className="p-2 hover:bg-gray-100 rounded-lg transition"
                title="Settings"
              >
                <Settings className="w-5 h-5 text-gray-600" />
              </button>
              <button
                onClick={handleSignOut}
                className="p-2 hover:bg-gray-100 rounded-lg transition"
                title="Sign Out"
              >
                <LogOut className="w-5 h-5 text-gray-600" />
              </button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-violet-100 rounded-lg">
                <BarChart3 className="w-6 h-6 text-violet-600" />
              </div>
              <div>
                <div className="text-2xl font-bold text-gray-900">{posts.length}</div>
                <div className="text-sm text-gray-600">Total Posts</div>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-green-100 rounded-lg">
                <BarChart3 className="w-6 h-6 text-green-600" />
              </div>
              <div>
                <div className="text-2xl font-bold text-gray-900">{publishedPosts}</div>
                <div className="text-sm text-gray-600">Published</div>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-orange-100 rounded-lg">
                <BarChart3 className="w-6 h-6 text-orange-600" />
              </div>
              <div>
                <div className="text-2xl font-bold text-gray-900">{upcomingPosts}</div>
                <div className="text-sm text-gray-600">Scheduled</div>
              </div>
            </div>
          </div>
        </div>

        {pendingApprovals > 0 && (
          <div className="mb-6 p-4 bg-orange-50 border border-orange-200 rounded-xl flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-orange-100 rounded-lg">
                <TrendingUp className="w-5 h-5 text-orange-600" />
              </div>
              <div>
                <div className="font-semibold text-gray-900">{pendingApprovals} posts waiting for approval</div>
                <div className="text-sm text-gray-600">Review and approve posts before they go live</div>
              </div>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          <button
            onClick={() => {
              setSelectedPost(null);
              setShowPostEditor(true);
            }}
            className="p-6 bg-white rounded-xl border-2 border-dashed border-gray-300 hover:border-violet-500 hover:bg-violet-50 transition text-left group"
          >
            <div className="flex items-center gap-3 mb-2">
              <div className="p-2 bg-violet-100 group-hover:bg-violet-200 rounded-lg transition">
                <Plus className="w-5 h-5 text-violet-600" />
              </div>
              <span className="font-semibold text-gray-900">Create Post</span>
            </div>
            <p className="text-sm text-gray-600">Write and schedule a new post</p>
          </button>

          <button
            onClick={() => setShowAIImageGen(true)}
            className="p-6 bg-white rounded-xl border-2 border-dashed border-gray-300 hover:border-purple-500 hover:bg-purple-50 transition text-left group"
          >
            <div className="flex items-center gap-3 mb-2">
              <div className="p-2 bg-purple-100 group-hover:bg-purple-200 rounded-lg transition">
                <Sparkles className="w-5 h-5 text-purple-600" />
              </div>
              <span className="font-semibold text-gray-900">AI Image Generator</span>
            </div>
            <p className="text-sm text-gray-600">Create stunning images from text</p>
          </button>

        </div>


        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-semibold text-gray-900">Content Calendar</h2>
        </div>

        <CalendarView
          posts={posts}
          onDateClick={handleDateClick}
          onPostClick={handlePostClick}
          onDeletePost={handleDeletePost}
        />
      </main>

      {showPostEditor && brand && (
        <PostEditor
          post={selectedPost || undefined}
          brandId={brand.id}
          brandVoice={brand.brand_voice || undefined}
          accounts={accounts}
          onClose={() => {
            setShowPostEditor(false);
            setSelectedPost(null);
          }}
          onSave={() => {
            loadPosts(brand.id);
          }}
        />
      )}

      {showAIImageGen && brand && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden flex flex-col">
            <div className="p-6 border-b border-gray-200 flex items-center justify-between">
              <h2 className="text-2xl font-bold text-gray-900">AI Image Generator</h2>
              <button
                onClick={() => setShowAIImageGen(false)}
                className="p-2 hover:bg-gray-100 rounded-lg transition"
              >
                <Plus className="w-6 h-6 text-gray-600 rotate-45" />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto p-6">
              <AIImageGenerator
                onImageGenerated={handleImageGenerated}
              />
            </div>
          </div>
        </div>
      )}


      {showApproval && pendingApprovalPost && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-hidden flex flex-col">
            <div className="flex-1 overflow-y-auto p-6">
              <ApprovalWorkflow
                post={pendingApprovalPost}
                onApprove={() => {
                  setShowApproval(false);
                  loadPosts(brand!.id);
                }}
                onReject={() => {
                  setShowApproval(false);
                  loadPosts(brand!.id);
                }}
                onClose={() => {
                  setShowApproval(false);
                  setPendingApprovalPost(null);
                }}
                onEdit={() => {
                  setSelectedPost(pendingApprovalPost);
                  setShowApproval(false);
                  setShowPostEditor(true);
                }}
              />
            </div>
          </div>
        </div>
      )}

      {showAIChat && brand && (
        <div className="fixed bottom-4 right-4 w-96 h-[600px] bg-white rounded-xl shadow-2xl border border-gray-200 z-50 flex flex-col overflow-hidden">
          <AIAssistantChat
            brandVoice={brand.brand_voice || undefined}
            contentPillars={(brand.content_pillars as string[]) || []}
            onApplySuggestion={(type, content) => {
              console.log('Apply suggestion:', type, content);
            }}
            onClose={() => setShowAIChat(false)}
          />
        </div>
      )}

      {showPublishModal && brand && (
        <PublishModal
          posts={posts}
          accounts={accounts}
          onClose={() => setShowPublishModal(false)}
          onPublished={() => {
            setShowPublishModal(false);
            loadPosts(brand.id);
          }}
        />
      )}

    </div>
  );
}
