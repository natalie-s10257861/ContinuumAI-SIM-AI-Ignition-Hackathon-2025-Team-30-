import { Twitter, Linkedin, Instagram, Facebook } from 'lucide-react';

interface PlatformPreviewProps {
  platform: 'twitter' | 'linkedin' | 'instagram' | 'facebook';
  content: string;
  imageUrl?: string;
  accountName: string;
}

export default function PlatformPreview({
  platform,
  content,
  imageUrl,
  accountName,
}: PlatformPreviewProps) {
  const platformConfig = {
    twitter: {
      Icon: Twitter,
      color: 'bg-violet-400',
      name: 'Twitter',
      maxChars: 280,
    },
    linkedin: {
      Icon: Linkedin,
      color: 'bg-violet-600',
      name: 'LinkedIn',
      maxChars: 3000,
    },
    instagram: {
      Icon: Instagram,
      color: 'bg-gradient-to-br from-pink-500 to-purple-600',
      name: 'Instagram',
      maxChars: 2200,
    },
    facebook: {
      Icon: Facebook,
      color: 'bg-violet-500',
      name: 'Facebook',
      maxChars: 63206,
    },
  };

  const config = platformConfig[platform];
  const Icon = config.Icon;
  const charCount = content.length;
  const isOverLimit = charCount > config.maxChars;

  return (
    <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
      <div className="p-4 bg-gray-50 border-b border-gray-200 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className={`p-1.5 ${config.color} rounded`}>
            <Icon className="w-4 h-4 text-white" />
          </div>
          <span className="text-sm font-medium text-gray-900">{config.name} Preview</span>
        </div>
        <div className={`text-xs ${isOverLimit ? 'text-red-600' : 'text-gray-500'}`}>
          {charCount} / {config.maxChars}
        </div>
      </div>

      <div className="p-4">
        <div className="flex items-start gap-3 mb-3">
          <div className={`w-10 h-10 ${config.color} rounded-full flex items-center justify-center flex-shrink-0`}>
            <Icon className="w-5 h-5 text-white" />
          </div>
          <div className="flex-1">
            <div className="font-semibold text-gray-900 text-sm">@{accountName}</div>
            <div className="text-xs text-gray-500">Just now</div>
          </div>
        </div>

        <div className="text-gray-900 text-sm whitespace-pre-wrap mb-3">{content || 'Your content will appear here...'}</div>

        {imageUrl && (
          <img
            src={imageUrl}
            alt="Post preview"
            className="w-full rounded-lg border border-gray-200 object-cover"
            style={{ maxHeight: '400px' }}
          />
        )}

        <div className="mt-4 pt-3 border-t border-gray-100 flex items-center gap-6 text-gray-500 text-xs">
          {platform === 'twitter' && (
            <>
              <span>💬 Reply</span>
              <span>🔁 Retweet</span>
              <span>❤️ Like</span>
              <span>📤 Share</span>
            </>
          )}
          {platform === 'linkedin' && (
            <>
              <span>👍 Like</span>
              <span>💬 Comment</span>
              <span>🔄 Repost</span>
              <span>📤 Send</span>
            </>
          )}
          {platform === 'instagram' && (
            <>
              <span>❤️ Like</span>
              <span>💬 Comment</span>
              <span>📤 Share</span>
              <span>🔖 Save</span>
            </>
          )}
          {platform === 'facebook' && (
            <>
              <span>👍 Like</span>
              <span>💬 Comment</span>
              <span>↗️ Share</span>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
