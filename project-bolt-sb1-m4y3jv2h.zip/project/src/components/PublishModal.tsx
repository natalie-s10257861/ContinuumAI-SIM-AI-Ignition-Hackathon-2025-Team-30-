import { useState, useEffect } from 'react';
import { X, Send, CheckCircle, AlertCircle, Facebook, Linkedin, Instagram, Loader } from 'lucide-react';
import { ContentPost, SocialAccount, supabase } from '../lib/supabase';
import { publishToSocialMedia } from '../lib/socialPublishing';

interface PublishModalProps {
  posts: ContentPost[];
  accounts: SocialAccount[];
  onClose: () => void;
  onPublished: () => void;
}

export default function PublishModal({ posts, accounts, onClose, onPublished }: PublishModalProps) {
  const [selectedPosts, setSelectedPosts] = useState<string[]>([]);
  const [selectedPlatforms, setSelectedPlatforms] = useState<string[]>([]);
  const [publishing, setPublishing] = useState(false);
  const [publishResults, setPublishResults] = useState<{ postId: string; platform: string; success: boolean; error?: string }[]>([]);
  const [showResults, setShowResults] = useState(false);

  const readyPosts = posts.filter(p =>
    p.status === 'scheduled' &&
    new Date(p.scheduled_date) <= new Date()
  );

  const connectedAccounts = accounts.filter(a => a.account_name && a.account_name.trim() !== '');

  const platformConfig = {
    facebook: { name: 'Facebook', icon: Facebook, color: 'blue' },
    instagram: { name: 'Instagram', icon: Instagram, color: 'pink' },
    linkedin: { name: 'LinkedIn', icon: Linkedin, color: 'blue' },
  };

  useEffect(() => {
    if (readyPosts.length > 0) {
      setSelectedPosts(readyPosts.map(p => p.id));
    }
    if (connectedAccounts.length > 0) {
      setSelectedPlatforms(connectedAccounts.map(a => a.platform));
    }
  }, []);

  const togglePost = (postId: string) => {
    setSelectedPosts(prev =>
      prev.includes(postId)
        ? prev.filter(id => id !== postId)
        : [...prev, postId]
    );
  };

  const togglePlatform = (platform: string) => {
    setSelectedPlatforms(prev =>
      prev.includes(platform)
        ? prev.filter(p => p !== platform)
        : [...prev, platform]
    );
  };

  const handlePublish = async () => {
    if (selectedPosts.length === 0 || selectedPlatforms.length === 0) {
      alert('Please select at least one post and one platform');
      return;
    }

    setPublishing(true);
    const results: { postId: string; platform: string; success: boolean; error?: string }[] = [];

    for (const postId of selectedPosts) {
      const post = readyPosts.find(p => p.id === postId);
      if (!post) continue;

      for (const platform of selectedPlatforms) {
        const account = connectedAccounts.find(a => a.platform === platform);
        if (!account) continue;

        const result = await publishToSocialMedia(
          account,
          post.content,
          post.media_url || undefined
        );

        results.push({
          postId: post.id,
          platform,
          success: result.success,
          error: result.error,
        });

        if (result.success) {
          await supabase
            .from('content_posts')
            .update({
              status: 'published',
              published_at: new Date().toISOString(),
            })
            .eq('id', post.id);
        }
      }
    }

    setPublishResults(results);
    setPublishing(false);
    setShowResults(true);
  };

  const handleClose = () => {
    if (publishResults.some(r => r.success)) {
      onPublished();
    }
    onClose();
  };

  if (connectedAccounts.length === 0) {
    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
        <div className="bg-white rounded-xl shadow-2xl max-w-md w-full p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold text-gray-900">No Connected Accounts</h2>
            <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-lg">
              <X className="w-5 h-5 text-gray-600" />
            </button>
          </div>
          <div className="text-center py-8">
            <AlertCircle className="w-16 h-16 text-orange-500 mx-auto mb-4" />
            <p className="text-gray-700 mb-4">
              You need to save at least one social media username/email before publishing.
            </p>
            <p className="text-sm text-gray-600">
              Go to Settings, click "Manage Connections", enter your username or email for any platform, and save.
            </p>
          </div>
          <button
            onClick={onClose}
            className="w-full px-4 py-2 bg-violet-600 hover:bg-violet-700 text-white rounded-lg transition"
          >
            Got it
          </button>
        </div>
      </div>
    );
  }

  if (readyPosts.length === 0) {
    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
        <div className="bg-white rounded-xl shadow-2xl max-w-md w-full p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold text-gray-900">No Posts Ready</h2>
            <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-lg">
              <X className="w-5 h-5 text-gray-600" />
            </button>
          </div>
          <div className="text-center py-8">
            <AlertCircle className="w-16 h-16 text-orange-500 mx-auto mb-4" />
            <p className="text-gray-700 mb-4">
              No posts are scheduled for publishing at this time.
            </p>
            <p className="text-sm text-gray-600">
              Posts must be scheduled for the current time or earlier to be published.
            </p>
          </div>
          <button
            onClick={onClose}
            className="w-full px-4 py-2 bg-violet-600 hover:bg-violet-700 text-white rounded-lg transition"
          >
            Got it
          </button>
        </div>
      </div>
    );
  }

  if (showResults) {
    const successCount = publishResults.filter(r => r.success).length;
    const failureCount = publishResults.filter(r => !r.success).length;

    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
        <div className="bg-white rounded-xl shadow-2xl max-w-2xl w-full max-h-[80vh] overflow-hidden flex flex-col">
          <div className="p-6 border-b border-gray-200 flex items-center justify-between">
            <h2 className="text-2xl font-bold text-gray-900">Publishing Results</h2>
            <button onClick={handleClose} className="p-2 hover:bg-gray-100 rounded-lg">
              <X className="w-5 h-5 text-gray-600" />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto p-6">
            {successCount > 0 && (
              <div className="bg-green-50 border-2 border-green-200 rounded-xl p-6 mb-6 text-center">
                <CheckCircle className="w-16 h-16 text-green-600 mx-auto mb-3" />
                <h3 className="text-2xl font-bold text-green-900 mb-2">Successfully Uploaded!</h3>
                <p className="text-green-700">
                  {successCount} post{successCount !== 1 ? 's' : ''} published to {selectedPlatforms.length} platform{selectedPlatforms.length !== 1 ? 's' : ''}
                </p>
              </div>
            )}

            {failureCount > 0 && (
              <div className="bg-red-50 border-2 border-red-200 rounded-xl p-6 mb-6 text-center">
                <AlertCircle className="w-16 h-16 text-red-600 mx-auto mb-3" />
                <h3 className="text-xl font-bold text-red-900 mb-2">Some Posts Failed</h3>
                <p className="text-red-700">{failureCount} post{failureCount !== 1 ? 's' : ''} could not be published</p>
              </div>
            )}

            <div className="space-y-3">
              {publishResults.map((result, index) => {
                const post = readyPosts.find(p => p.id === result.postId);
                const config = platformConfig[result.platform as keyof typeof platformConfig];
                const Icon = config?.icon || Send;

                return (
                  <div
                    key={index}
                    className={`p-4 rounded-lg border ${
                      result.success
                        ? 'bg-green-50 border-green-200'
                        : 'bg-red-50 border-red-200'
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      <div className={`p-2 rounded-lg ${result.success ? 'bg-green-100' : 'bg-red-100'}`}>
                        <Icon className={`w-5 h-5 ${result.success ? 'text-green-600' : 'text-red-600'}`} />
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-semibold text-gray-900">{post?.title || 'Untitled'}</span>
                          <span className="text-sm text-gray-600">→ {config?.name}</span>
                          {result.success ? (
                            <CheckCircle className="w-4 h-4 text-green-600" />
                          ) : (
                            <AlertCircle className="w-4 h-4 text-red-600" />
                          )}
                        </div>
                        <p className="text-sm text-gray-600 line-clamp-1">{post?.content}</p>
                        {!result.success && result.error && (
                          <p className="text-sm text-red-600 mt-1">{result.error}</p>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="p-6 border-t border-gray-200">
            <button
              onClick={handleClose}
              className="w-full px-4 py-3 bg-violet-600 hover:bg-violet-700 text-white rounded-lg transition font-medium"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden flex flex-col">
        <div className="p-6 border-b border-gray-200 flex items-center justify-between">
          <h2 className="text-2xl font-bold text-gray-900">Publish Posts</h2>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-lg">
            <X className="w-5 h-5 text-gray-600" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-6">
          <div className="mb-8">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Select Platforms</h3>
            <div className="grid grid-cols-3 gap-4">
              {Object.entries(platformConfig).map(([platform, config]) => {
                const account = connectedAccounts.find(a => a.platform === platform);
                if (!account) return null;

                const Icon = config.icon;
                const isSelected = selectedPlatforms.includes(platform);

                return (
                  <button
                    key={platform}
                    onClick={() => togglePlatform(platform)}
                    className={`p-4 rounded-xl border-2 transition ${
                      isSelected
                        ? 'border-violet-500 bg-violet-50'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className={`p-2 rounded-lg bg-${config.color}-100`}>
                        <Icon className={`w-6 h-6 text-${config.color}-600`} />
                      </div>
                      <div className="flex-1 text-left">
                        <div className="font-semibold text-gray-900">{config.name}</div>
                        <div className="text-xs text-gray-600">{account.account_name}</div>
                      </div>
                      {isSelected && (
                        <CheckCircle className="w-5 h-5 text-violet-600" />
                      )}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold text-gray-900 mb-4">
              Select Posts ({selectedPosts.length} of {readyPosts.length} selected)
            </h3>
            <div className="space-y-3">
              {readyPosts.map((post) => {
                const isSelected = selectedPosts.includes(post.id);

                return (
                  <button
                    key={post.id}
                    onClick={() => togglePost(post.id)}
                    className={`w-full p-4 rounded-xl border-2 transition text-left ${
                      isSelected
                        ? 'border-violet-500 bg-violet-50'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      <div className={`mt-1 w-5 h-5 rounded border-2 flex items-center justify-center ${
                        isSelected
                          ? 'bg-violet-600 border-violet-600'
                          : 'border-gray-300'
                      }`}>
                        {isSelected && (
                          <CheckCircle className="w-4 h-4 text-white" />
                        )}
                      </div>
                      <div className="flex-1">
                        <div className="font-semibold text-gray-900 mb-1">{post.title}</div>
                        <p className="text-sm text-gray-600 line-clamp-2 mb-2">{post.content}</p>
                        <div className="flex items-center gap-4 text-xs text-gray-500">
                          <span>Scheduled: {new Date(post.scheduled_date).toLocaleString()}</span>
                          {post.media_url && (
                            <span className="flex items-center gap-1">
                              <CheckCircle className="w-3 h-3" />
                              Has image
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        <div className="p-6 border-t border-gray-200">
          <div className="flex gap-3">
            <button
              onClick={onClose}
              className="flex-1 px-4 py-3 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-lg transition font-medium"
            >
              Cancel
            </button>
            <button
              onClick={handlePublish}
              disabled={publishing || selectedPosts.length === 0 || selectedPlatforms.length === 0}
              className="flex-1 px-4 py-3 bg-violet-600 hover:bg-violet-700 text-white rounded-lg transition font-medium disabled:opacity-50 flex items-center justify-center gap-2"
            >
              {publishing ? (
                <>
                  <Loader className="w-5 h-5 animate-spin" />
                  Publishing...
                </>
              ) : (
                <>
                  <Send className="w-5 h-5" />
                  Publish to {selectedPlatforms.length} Platform{selectedPlatforms.length !== 1 ? 's' : ''}
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
