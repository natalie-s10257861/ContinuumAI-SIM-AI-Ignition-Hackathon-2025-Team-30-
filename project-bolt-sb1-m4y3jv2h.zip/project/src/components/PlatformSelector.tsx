import { Twitter, Linkedin, Instagram, Facebook } from 'lucide-react';
import { SocialAccount } from '../lib/supabase';

interface PlatformSelectorProps {
  accounts: SocialAccount[];
  selectedAccounts: string[];
  onToggleAccount: (accountId: string) => void;
}

const platformIcons = {
  twitter: Twitter,
  linkedin: Linkedin,
  instagram: Instagram,
  facebook: Facebook,
};

const platformColors = {
  twitter: 'from-violet-400 to-violet-600',
  linkedin: 'from-violet-600 to-violet-800',
  instagram: 'from-pink-500 to-purple-600',
  facebook: 'from-violet-500 to-violet-700',
};

export default function PlatformSelector({
  accounts,
  selectedAccounts,
  onToggleAccount,
}: PlatformSelectorProps) {
  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
      {accounts.map((account) => {
        const Icon = platformIcons[account.platform];
        const isSelected = selectedAccounts.includes(account.id);

        return (
          <button
            key={account.id}
            onClick={() => onToggleAccount(account.id)}
            className={`
              relative p-4 rounded-xl border-2 transition-all h-32 flex flex-col items-center justify-center
              ${isSelected
                ? 'border-violet-500 bg-violet-50 shadow-md'
                : 'border-gray-200 hover:border-gray-300 bg-white'
              }
            `}
          >
            {isSelected && (
              <div className="absolute top-2 right-2 w-5 h-5 bg-violet-500 rounded-full flex items-center justify-center">
                <svg className="w-3 h-3 text-white" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                </svg>
              </div>
            )}

            <div className={`
              w-10 h-10 rounded-lg bg-gradient-to-br ${platformColors[account.platform]}
              flex items-center justify-center mb-2
            `}>
              <Icon className="w-5 h-5 text-white" />
            </div>

            <div className="text-center w-full">
              <div className="text-sm font-semibold text-gray-900 capitalize truncate px-1">
                {account.platform}
              </div>
              <div className="text-xs text-gray-600 mt-0.5 truncate px-1">
                @{account.account_name}
              </div>
            </div>
          </button>
        );
      })}
    </div>
  );
}
