import { useState, useEffect } from 'react';
import { Save, Plus, X, Link as LinkIcon } from 'lucide-react';
import { supabase, Brand, SocialAccount } from '../lib/supabase';
import SocialAccountConnect from './SocialAccountConnect';

interface BrandSetupProps {
  onSave: () => void;
}

export default function BrandSetup({ onSave }: BrandSetupProps) {
  const [brandName, setBrandName] = useState('');
  const [brandVoice, setBrandVoice] = useState('');
  const [contentPillars, setContentPillars] = useState<string[]>([]);
  const [newPillar, setNewPillar] = useState('');
  const [primaryColor, setPrimaryColor] = useState('#0066cc');
  const [secondaryColor, setSecondaryColor] = useState('#ffffff');
  const [accentColor, setAccentColor] = useState('#000000');
  const [accounts, setAccounts] = useState<{ platform: string; accountName: string }[]>([]);
  const [socialAccounts, setSocialAccounts] = useState<SocialAccount[]>([]);
  const [saving, setSaving] = useState(false);
  const [existingBrand, setExistingBrand] = useState<Brand | null>(null);
  const [showConnectAccounts, setShowConnectAccounts] = useState(false);

  useEffect(() => {
    loadExistingBrand();
  }, []);

  const loadExistingBrand = async () => {
    const { data: userData } = await supabase.auth.getUser();
    if (!userData.user) return;

    const { data: brandData } = await supabase
      .from('brands')
      .select('*')
      .eq('user_id', userData.user.id)
      .single();

    if (brandData) {
      setExistingBrand(brandData);
      setBrandName(brandData.name);
      setBrandVoice(brandData.brand_voice || '');
      setContentPillars((brandData.content_pillars as string[]) || []);
      setPrimaryColor(brandData.brand_colors.primary);
      setSecondaryColor(brandData.brand_colors.secondary);
      setAccentColor(brandData.brand_colors.accent);

      const { data: accountsData } = await supabase
        .from('social_accounts')
        .select('*')
        .eq('brand_id', brandData.id);

      if (accountsData) {
        setAccounts(
          accountsData.map(acc => ({
            platform: acc.platform,
            accountName: acc.account_name,
          }))
        );
        setSocialAccounts(accountsData);
      }
    }
  };

  const addAccount = () => {
    setAccounts([...accounts, { platform: 'twitter', accountName: '' }]);
  };

  const removeAccount = (index: number) => {
    setAccounts(accounts.filter((_, i) => i !== index));
  };

  const updateAccount = (index: number, field: 'platform' | 'accountName', value: string) => {
    const updated = [...accounts];
    updated[index][field] = value;
    setAccounts(updated);
  };

  const handleSave = async () => {
    if (!brandName.trim()) return;

    setSaving(true);
    try {
      const { data: userData } = await supabase.auth.getUser();
      if (!userData.user) return;

      const brandData = {
        name: brandName.trim(),
        brand_voice: brandVoice.trim() || null,
        content_pillars: contentPillars,
        brand_colors: {
          primary: primaryColor,
          secondary: secondaryColor,
          accent: accentColor,
        },
        user_id: userData.user.id,
      };

      let brandId: string;

      if (existingBrand) {
        await supabase
          .from('brands')
          .update(brandData)
          .eq('id', existingBrand.id);
        brandId = existingBrand.id;

        await supabase
          .from('social_accounts')
          .delete()
          .eq('brand_id', brandId);
      } else {
        const { data: newBrand, error } = await supabase
          .from('brands')
          .insert([brandData])
          .select()
          .single();

        if (error) throw error;
        brandId = newBrand.id;
      }

      if (accounts.length > 0) {
        const accountsData = accounts
          .filter(acc => acc.accountName.trim())
          .map(acc => ({
            brand_id: brandId,
            platform: acc.platform,
            account_name: acc.accountName.trim(),
            is_connected: true,
          }));

        if (accountsData.length > 0) {
          await supabase.from('social_accounts').insert(accountsData);
        }
      }

      onSave();
    } catch (error) {
      console.error('Error saving brand:', error);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-violet-50 to-slate-100 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-xl max-w-2xl w-full p-8">
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-2">
            {existingBrand ? 'Brand Settings' : 'Setup Your Brand'}
          </h2>
          <p className="text-gray-600">
            Configure your brand identity and connect your social accounts
          </p>
        </div>

        <div className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Brand Name
            </label>
            <input
              type="text"
              value={brandName}
              onChange={(e) => setBrandName(e.target.value)}
              placeholder="Your Brand Name"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-violet-500 focus:border-transparent outline-none transition"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Brand Voice
            </label>
            <textarea
              value={brandVoice}
              onChange={(e) => setBrandVoice(e.target.value)}
              placeholder="Describe your brand's tone and personality for AI copywriting..."
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-violet-500 focus:border-transparent outline-none resize-none transition"
              rows={3}
            />
          </div>

          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="block text-sm font-medium text-gray-700">
                Content Pillars
              </label>
            </div>
            <div className="space-y-2">
              <div className="flex gap-2">
                <input
                  type="text"
                  value={newPillar}
                  onChange={(e) => setNewPillar(e.target.value)}
                  onKeyPress={(e) => {
                    if (e.key === 'Enter' && newPillar.trim()) {
                      setContentPillars([...contentPillars, newPillar.trim()]);
                      setNewPillar('');
                    }
                  }}
                  placeholder="E.g., Product Updates, Customer Stories..."
                  className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-violet-500 focus:border-transparent outline-none transition"
                />
                <button
                  onClick={() => {
                    if (newPillar.trim()) {
                      setContentPillars([...contentPillars, newPillar.trim()]);
                      setNewPillar('');
                    }
                  }}
                  className="px-4 py-2 bg-violet-600 hover:bg-violet-700 text-white rounded-lg transition"
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>
              <div className="flex flex-wrap gap-2">
                {contentPillars.map((pillar, idx) => (
                  <span
                    key={idx}
                    className="px-3 py-1 bg-violet-100 text-violet-700 rounded-full text-sm flex items-center gap-2"
                  >
                    {pillar}
                    <button
                      onClick={() => setContentPillars(contentPillars.filter((_, i) => i !== idx))}
                      className="hover:text-violet-900"
                    >
                      ×
                    </button>
                  </span>
                ))}
              </div>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-3">
              Brand Colors
            </label>
            <div className="grid grid-cols-3 gap-4">
              <div>
                <label className="block text-xs text-gray-600 mb-1">Primary</label>
                <input
                  type="color"
                  value={primaryColor}
                  onChange={(e) => setPrimaryColor(e.target.value)}
                  className="w-full h-10 rounded-lg cursor-pointer"
                />
              </div>
              <div>
                <label className="block text-xs text-gray-600 mb-1">Secondary</label>
                <input
                  type="color"
                  value={secondaryColor}
                  onChange={(e) => setSecondaryColor(e.target.value)}
                  className="w-full h-10 rounded-lg cursor-pointer"
                />
              </div>
              <div>
                <label className="block text-xs text-gray-600 mb-1">Accent</label>
                <input
                  type="color"
                  value={accentColor}
                  onChange={(e) => setAccentColor(e.target.value)}
                  className="w-full h-10 rounded-lg cursor-pointer"
                />
              </div>
            </div>
          </div>

          {existingBrand && (
            <div>
              <div className="flex items-center justify-between mb-3">
                <label className="block text-sm font-medium text-gray-700">
                  Connect Social Media Accounts
                </label>
                <button
                  onClick={() => setShowConnectAccounts(!showConnectAccounts)}
                  className="text-sm text-violet-600 hover:text-violet-700 font-medium flex items-center gap-1"
                >
                  <LinkIcon className="w-4 h-4" />
                  {showConnectAccounts ? 'Hide' : 'Manage Connections'}
                </button>
              </div>
              {showConnectAccounts && (
                <div className="mb-6">
                  <SocialAccountConnect
                    brandId={existingBrand.id}
                    accounts={socialAccounts}
                    onAccountsUpdated={loadExistingBrand}
                  />
                </div>
              )}
            </div>
          )}

          <div className="space-y-3">
            <button
              onClick={handleSave}
              disabled={saving || !brandName.trim()}
              className="w-full bg-violet-600 hover:bg-violet-700 text-white font-medium py-3 px-4 rounded-lg transition disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            >
              <Save className="w-5 h-5" />
              {saving ? 'Saving...' : existingBrand ? 'Update Brand' : 'Save & Continue'}
            </button>
            {!existingBrand && (
              <p className="text-xs text-gray-600 text-center">
                You can connect social media accounts after saving your brand
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
