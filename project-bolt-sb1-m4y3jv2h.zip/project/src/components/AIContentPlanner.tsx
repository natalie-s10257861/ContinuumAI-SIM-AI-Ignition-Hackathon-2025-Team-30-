import { useState } from 'react';
import { Calendar, Sparkles, TrendingUp } from 'lucide-react';
import { generateContentPlan, ContentTheme, SuggestedPost } from '../lib/contentPlanning';
import { supabase } from '../lib/supabase';

interface AIContentPlannerProps {
  brandId: string;
  brandVoice: string;
  contentPillars: string[];
  onPostSelected: (post: SuggestedPost) => void;
}

export default function AIContentPlanner({
  brandId,
  brandVoice,
  contentPillars,
  onPostSelected,
}: AIContentPlannerProps) {
  const [month, setMonth] = useState(new Date().getMonth() + 1);
  const [year, setYear] = useState(new Date().getFullYear());
  const [themes, setThemes] = useState<ContentTheme[]>([]);
  const [suggestedPosts, setSuggestedPosts] = useState<SuggestedPost[]>([]);
  const [loading, setLoading] = useState(false);
  const [showResults, setShowResults] = useState(false);

  const handleGenerate = async () => {
    setLoading(true);
    try {
      const plan = await generateContentPlan(brandVoice, contentPillars, month, year);
      setThemes(plan.themes);
      setSuggestedPosts(plan.suggestedPosts);
      setShowResults(true);

      await supabase.from('content_plans').upsert(
        {
          brand_id: brandId,
          month,
          year,
          themes: plan.themes,
          suggested_posts: plan.suggestedPosts,
          updated_at: new Date().toISOString(),
        },
        { onConflict: 'brand_id,month,year' }
      );
    } catch (error) {
      console.error('Error generating content plan:', error);
    } finally {
      setLoading(false);
    }
  };

  const monthName = new Date(year, month - 1).toLocaleDateString('en-US', { month: 'long' });

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
      <div className="flex items-center gap-3 mb-6">
        <div className="p-2 bg-gradient-to-br from-green-500 to-teal-600 rounded-lg">
          <TrendingUp className="w-5 h-5 text-white" />
        </div>
        <div>
          <h3 className="text-lg font-semibold text-gray-900">AI Content Planner</h3>
          <p className="text-sm text-gray-600">Generate strategic content calendar</p>
        </div>
      </div>

      {!showResults ? (
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Month</label>
              <select
                value={month}
                onChange={(e) => setMonth(parseInt(e.target.value))}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none transition"
              >
                {Array.from({ length: 12 }, (_, i) => (
                  <option key={i + 1} value={i + 1}>
                    {new Date(2024, i).toLocaleDateString('en-US', { month: 'long' })}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Year</label>
              <select
                value={year}
                onChange={(e) => setYear(parseInt(e.target.value))}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none transition"
              >
                {Array.from({ length: 3 }, (_, i) => (
                  <option key={i} value={new Date().getFullYear() + i}>
                    {new Date().getFullYear() + i}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <button
            onClick={handleGenerate}
            disabled={loading}
            className="w-full bg-gradient-to-r from-green-600 to-teal-600 hover:from-green-700 hover:to-teal-700 text-white font-medium py-2.5 px-4 rounded-lg transition disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            <Sparkles className="w-4 h-4" />
            {loading ? 'Generating Plan...' : `Generate Plan for ${monthName} ${year}`}
          </button>
        </div>
      ) : (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h4 className="text-lg font-semibold text-gray-900">
              {monthName} {year} Content Plan
            </h4>
            <button
              onClick={() => setShowResults(false)}
              className="text-sm text-violet-600 hover:text-violet-700 font-medium"
            >
              Generate New Plan
            </button>
          </div>

          <div>
            <h5 className="text-sm font-semibold text-gray-700 mb-3">Content Themes</h5>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {themes.map((theme, idx) => (
                <div key={idx} className="p-4 bg-green-50 border border-green-200 rounded-lg">
                  <div className="font-medium text-gray-900 mb-1">{theme.name}</div>
                  <div className="text-sm text-gray-600 mb-2">{theme.description}</div>
                  <div className="flex flex-wrap gap-1">
                    {theme.hashtags.map((tag, tagIdx) => (
                      <span
                        key={tagIdx}
                        className="text-xs px-2 py-1 bg-green-100 text-green-700 rounded"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div>
            <h5 className="text-sm font-semibold text-gray-700 mb-3">
              Suggested Posts ({suggestedPosts.length})
            </h5>
            <div className="space-y-2 max-h-96 overflow-y-auto">
              {suggestedPosts.map((post, idx) => (
                <div
                  key={idx}
                  className="p-4 bg-gray-50 border border-gray-200 rounded-lg hover:border-green-300 transition cursor-pointer"
                  onClick={() => onPostSelected(post)}
                >
                  <div className="flex items-start justify-between mb-2">
                    <div className="font-medium text-gray-900">{post.title}</div>
                    <span className="text-xs px-2 py-1 bg-violet-100 text-violet-700 rounded">
                      {new Date(post.suggestedDate).toLocaleDateString('en-US', {
                        month: 'short',
                        day: 'numeric',
                      })}
                    </span>
                  </div>
                  <div className="text-sm text-gray-600 mb-2">{post.content}</div>
                  <div className="flex items-center gap-2 text-xs text-gray-500">
                    <Calendar className="w-3 h-3" />
                    <span>{post.theme}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
