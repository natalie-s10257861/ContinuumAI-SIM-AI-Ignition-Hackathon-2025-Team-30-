import { useState, useRef, useEffect } from 'react';
import { Send, Bot, User, Sparkles, Calendar, Hash, Image, TrendingUp, X } from 'lucide-react';
import { generateAICopy } from '../lib/ai';
import { generateHashtags, generateContentPlan } from '../lib/contentPlanning';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  suggestions?: string[];
  timestamp: Date;
}

interface AIAssistantChatProps {
  brandVoice?: string;
  contentPillars?: string[];
  onApplySuggestion?: (type: string, content: any) => void;
  onClose?: () => void;
}

export default function AIAssistantChat({
  brandVoice,
  contentPillars = [],
  onApplySuggestion,
  onClose,
}: AIAssistantChatProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      role: 'assistant',
      content: "Hi! I'm your AI social media assistant. I can help you:\n\n• Generate post ideas and captions\n• Plan your content calendar\n• Suggest hashtags\n• Optimize posting times\n• Brainstorm campaign ideas\n\nWhat would you like help with today?",
      timestamp: new Date(),
    },
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const quickActions = [
    { icon: Sparkles, label: 'Generate post idea', prompt: 'Give me 3 post ideas for this week' },
    { icon: Calendar, label: 'Plan this month', prompt: 'Help me plan content for this month' },
    { icon: Hash, label: 'Suggest hashtags', prompt: 'What hashtags should I use?' },
    { icon: TrendingUp, label: 'Campaign ideas', prompt: 'Give me creative campaign ideas' },
  ];

  const handleSend = async (message: string) => {
    if (!message.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: message,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput('');
    setLoading(true);

    try {
      let response = '';
      let suggestions: string[] = [];

      const lowerMessage = message.toLowerCase();

      if (lowerMessage.includes('post idea') || lowerMessage.includes('content idea')) {
        const ideas = [
          `Share a customer success story highlighting how your product solved a real problem`,
          `Behind-the-scenes look at your team or product development process`,
          `Industry insight: Share your take on a recent trend or news`,
          `Quick tip or how-to related to your product`,
          `Celebrate a milestone or achievement with your community`,
        ];
        response = `Here are some engaging post ideas:\n\n${ideas.map((idea, i) => `${i + 1}. ${idea}`).join('\n\n')}`;
        suggestions = ideas;
      } else if (lowerMessage.includes('hashtag')) {
        const tags = generateHashtags(message, 'instagram');
        response = `Here are relevant hashtags for your content:\n\n${tags.join(' ')}\n\nRemember:\n• Instagram: Use up to 15 hashtags\n• Twitter: Keep it to 1-2 hashtags\n• LinkedIn: Use 3-5 professional hashtags`;
        suggestions = tags;
      } else if (lowerMessage.includes('plan') || lowerMessage.includes('calendar') || lowerMessage.includes('schedule')) {
        const themes = contentPillars.length > 0 ? contentPillars : ['Product Updates', 'Customer Stories', 'Industry Insights'];
        response = `Let's plan your content strategy:\n\n📅 Weekly Theme Ideas:\n${themes.map((theme, i) => `• ${theme}`).join('\n')}\n\n📊 Suggested Posting Frequency:\n• Twitter: 5 posts/week\n• LinkedIn: 3 posts/week\n• Instagram: 4 posts/week\n• Facebook: 3 posts/week\n\n💡 Best Times:\n• B2B: Tue-Thu, 9am-11am\n• B2C: Wed-Fri, 1pm-3pm\n\nWould you like me to generate specific post ideas for any of these themes?`;
      } else if (lowerMessage.includes('campaign')) {
        response = `Here are some campaign ideas for your brand:\n\n1. 🎯 Challenge Campaign: Create a branded challenge encouraging user participation\n2. 💬 AMA Series: Host Ask Me Anything sessions with your team\n3. 🎁 Giveaway Contest: Boost engagement with a strategic giveaway\n4. 📸 User-Generated Content: Feature customer stories and photos\n5. 🚀 Launch Countdown: Build excitement for upcoming features\n\nEach campaign can run for 2-4 weeks with daily posts!`;
      } else if (lowerMessage.includes('write') || lowerMessage.includes('caption') || lowerMessage.includes('copy')) {
        const generatedCopy = await generateAICopy({
          prompt: message,
          platform: 'linkedin',
          brandVoice,
          tone: 'professional',
        });
        response = `Here's a caption for you:\n\n${generatedCopy}\n\nWould you like me to create versions for other platforms?`;
        suggestions = ['Create Twitter version', 'Create Instagram version', 'Add more hashtags'];
      } else if (lowerMessage.includes('help') || lowerMessage.includes('what can you')) {
        response = `I can assist you with:\n\n📝 Content Creation:\n• Generate post captions\n• Write compelling copy\n• Create content variations\n\n📅 Planning:\n• Monthly content calendars\n• Posting schedules\n• Theme suggestions\n\n🎯 Strategy:\n• Campaign ideas\n• Hashtag research\n• Audience engagement tips\n\n✨ Optimization:\n• Best posting times\n• Platform-specific advice\n• Performance insights\n\nJust tell me what you need help with!`;
      } else {
        response = `I understand you're asking about: "${message}"\n\nLet me help! For the best results, try asking me to:\n• "Generate post ideas for [topic]"\n• "Write a caption about [subject]"\n• "Help me plan content for [timeframe]"\n• "Suggest hashtags for [industry/topic]"\n• "Give me campaign ideas"\n\nWhat specific aspect would you like help with?`;
      }

      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: response,
        suggestions,
        timestamp: new Date(),
      };

      setMessages((prev) => [...prev, assistantMessage]);
    } catch (error) {
      console.error('Error generating response:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleQuickAction = (prompt: string) => {
    handleSend(prompt);
  };

  return (
    <div className="flex flex-col h-full">
      <div className="p-4 border-b border-gray-200 bg-gradient-to-r from-violet-50 to-purple-50">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            {onClose ? (
              <button
                onClick={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  onClose();
                }}
                className="p-2 bg-gradient-to-br from-violet-500 to-purple-600 rounded-lg hover:from-violet-600 hover:to-purple-700 transition cursor-pointer"
                title="Click to close AI Assistant"
                type="button"
              >
                <Bot className="w-5 h-5 text-white" />
              </button>
            ) : (
              <div className="p-2 bg-gradient-to-br from-violet-500 to-purple-600 rounded-lg">
                <Bot className="w-5 h-5 text-white" />
              </div>
            )}
            <div className="flex-1">
              <h3 className="font-semibold text-gray-900">AI Content Assistant</h3>
              <p className="text-xs text-gray-600">Click bot icon to close</p>
            </div>
          </div>
          {onClose && (
            <button
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                onClose();
              }}
              className="p-2 bg-gray-800 hover:bg-gray-900 text-white rounded-lg transition shadow-sm"
              title="Close AI Assistant"
              type="button"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((message) => (
          <div
            key={message.id}
            className={`flex gap-3 ${message.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}
          >
            <div
              className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center ${
                message.role === 'user'
                  ? 'bg-violet-600'
                  : 'bg-gradient-to-br from-violet-500 to-purple-600'
              }`}
            >
              {message.role === 'user' ? (
                <User className="w-4 h-4 text-white" />
              ) : (
                <Bot className="w-4 h-4 text-white" />
              )}
            </div>
            <div
              className={`flex-1 max-w-[80%] ${
                message.role === 'user' ? 'items-end' : 'items-start'
              }`}
            >
              <div
                className={`rounded-2xl px-4 py-3 ${
                  message.role === 'user'
                    ? 'bg-violet-600 text-white'
                    : 'bg-gray-100 text-gray-900'
                }`}
              >
                <p className="text-sm whitespace-pre-wrap">{message.content}</p>
              </div>
              {message.suggestions && message.suggestions.length > 0 && (
                <div className="mt-2 flex flex-wrap gap-2">
                  {message.suggestions.slice(0, 3).map((suggestion, idx) => (
                    <button
                      key={idx}
                      onClick={() => onApplySuggestion?.('suggestion', suggestion)}
                      className="text-xs px-3 py-1 bg-white border border-gray-300 hover:border-violet-500 rounded-full text-gray-700 hover:text-violet-600 transition"
                    >
                      {suggestion.slice(0, 40)}...
                    </button>
                  ))}
                </div>
              )}
              <p className="text-xs text-gray-500 mt-1">
                {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </p>
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex gap-3">
            <div className="flex-shrink-0 w-8 h-8 rounded-full bg-gradient-to-br from-violet-500 to-purple-600 flex items-center justify-center">
              <Bot className="w-4 h-4 text-white" />
            </div>
            <div className="bg-gray-100 rounded-2xl px-4 py-3">
              <div className="flex gap-1">
                <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" />
                <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce delay-100" />
                <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce delay-200" />
              </div>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      <div className="p-4 border-t border-gray-200 bg-gray-50">
        <div className="flex flex-wrap gap-2 mb-3">
          {quickActions.map((action, idx) => (
            <button
              key={idx}
              onClick={() => handleQuickAction(action.prompt)}
              className="text-xs px-3 py-2 bg-white border border-gray-300 hover:border-violet-500 rounded-lg text-gray-700 hover:text-violet-600 transition flex items-center gap-2"
            >
              <action.icon className="w-3 h-3" />
              {action.label}
            </button>
          ))}
        </div>
        <div className="flex gap-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSend(input)}
            placeholder="Ask me anything about your social media..."
            className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-violet-500 focus:border-transparent outline-none transition"
          />
          <button
            onClick={() => handleSend(input)}
            disabled={!input.trim() || loading}
            className="px-4 py-2 bg-violet-600 hover:bg-violet-700 text-white rounded-lg transition disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Send className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
}
