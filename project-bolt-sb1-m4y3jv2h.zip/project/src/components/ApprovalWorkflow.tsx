import { useState, useEffect } from 'react';
import { CheckCircle, XCircle, AlertCircle, MessageSquare, Edit } from 'lucide-react';
import { supabase, ContentPost } from '../lib/supabase';

interface ApprovalWorkflowProps {
  post: ContentPost;
  onApprove: () => void;
  onReject: () => void;
  onClose: () => void;
  onEdit: () => void;
}

interface Approval {
  status: 'pending' | 'approved' | 'rejected' | 'needs_changes';
  reviewer_notes: string | null;
}

export default function ApprovalWorkflow({ post, onApprove, onReject, onClose, onEdit }: ApprovalWorkflowProps) {
  const [approval, setApproval] = useState<Approval | null>(null);
  const [notes, setNotes] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadApproval();
  }, [post.id]);

  const loadApproval = async () => {
    const { data } = await supabase
      .from('post_approvals')
      .select('*')
      .eq('post_id', post.id)
      .order('created_at', { ascending: false })
      .limit(1)
      .maybeSingle();

    if (data) {
      setApproval(data);
      setNotes(data.reviewer_notes || '');
    }
  };

  const handleApproval = async (status: 'approved' | 'rejected' | 'needs_changes') => {
    setLoading(true);
    try {
      await supabase.from('post_approvals').insert([
        {
          post_id: post.id,
          status,
          reviewer_notes: notes.trim() || null,
          approved_at: status === 'approved' ? new Date().toISOString() : null,
        },
      ]);

      if (status === 'approved') {
        await supabase
          .from('content_posts')
          .update({ status: 'scheduled' })
          .eq('id', post.id);
        onApprove();
      } else if (status === 'rejected') {
        await supabase
          .from('content_posts')
          .update({ status: 'draft' })
          .eq('id', post.id);
        onReject();
      }

      onClose();
    } catch (error) {
      console.error('Error updating approval:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
      <div className="flex items-center gap-3 mb-6">
        <div className="p-2 bg-orange-100 rounded-lg">
          <AlertCircle className="w-5 h-5 text-orange-600" />
        </div>
        <div>
          <h3 className="text-lg font-semibold text-gray-900">Approval Required</h3>
          <p className="text-sm text-gray-600">Review and approve this post before scheduling</p>
        </div>
      </div>

      <div className="space-y-4">
        <div className="p-4 bg-gray-50 rounded-lg">
          <div className="font-medium text-gray-900 mb-2">{post.title}</div>
          <div className="text-sm text-gray-700 whitespace-pre-wrap">{post.content}</div>
          <div className="mt-3 text-xs text-gray-500">
            Scheduled for: {new Date(post.scheduled_date).toLocaleString()}
          </div>
        </div>

        {approval && approval.status !== 'pending' && (
          <div
            className={`p-4 rounded-lg ${
              approval.status === 'approved'
                ? 'bg-green-50 border border-green-200'
                : approval.status === 'rejected'
                ? 'bg-red-50 border border-red-200'
                : 'bg-yellow-50 border border-yellow-200'
            }`}
          >
            <div className="flex items-center gap-2 mb-2">
              {approval.status === 'approved' && (
                <>
                  <CheckCircle className="w-4 h-4 text-green-600" />
                  <span className="font-medium text-green-900">Approved</span>
                </>
              )}
              {approval.status === 'rejected' && (
                <>
                  <XCircle className="w-4 h-4 text-red-600" />
                  <span className="font-medium text-red-900">Rejected</span>
                </>
              )}
              {approval.status === 'needs_changes' && (
                <>
                  <AlertCircle className="w-4 h-4 text-yellow-600" />
                  <span className="font-medium text-yellow-900">Needs Changes</span>
                </>
              )}
            </div>
            {approval.reviewer_notes && (
              <div className="text-sm text-gray-700">{approval.reviewer_notes}</div>
            )}
          </div>
        )}

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2 flex items-center gap-2">
            <MessageSquare className="w-4 h-4" />
            Review Notes
          </label>
          <textarea
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="Add any feedback or notes..."
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-violet-500 focus:border-transparent outline-none resize-none transition"
            rows={3}
          />
        </div>

        <div className="grid grid-cols-3 gap-3">
          <button
            onClick={() => handleApproval('approved')}
            disabled={loading}
            className="bg-green-600 hover:bg-green-700 text-white font-medium py-2 px-4 rounded-lg transition disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            <CheckCircle className="w-4 h-4" />
            Approve
          </button>
          <button
            onClick={onEdit}
            className="bg-violet-600 hover:bg-violet-700 text-white font-medium py-2 px-4 rounded-lg transition flex items-center justify-center gap-2"
          >
            <Edit className="w-4 h-4" />
            Edit Post
          </button>
          <button
            onClick={() => handleApproval('rejected')}
            disabled={loading}
            className="bg-red-600 hover:bg-red-700 text-white font-medium py-2 px-4 rounded-lg transition disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            <XCircle className="w-4 h-4" />
            Reject
          </button>
        </div>
      </div>
    </div>
  );
}
