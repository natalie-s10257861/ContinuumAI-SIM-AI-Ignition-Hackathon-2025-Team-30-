import { useState } from 'react';
import { Facebook, Linkedin, Instagram, CheckCircle, Trash2 } from 'lucide-react';
import { supabase, SocialAccount } from '../lib/supabase';

interface SocialAccountConnectProps {
  brandId: string;
  accounts: SocialAccount[];
  onAccountsUpdated: () => void;
}

type Platform = 'facebook' | 'linkedin' | 'instagram';

export default function SocialAccountConnect({ brandId, accounts, onAccountsUpdated }: SocialAccountConnectProps) {
  const [showUsernameModal, setShowUsernameModal] = useState<Platform | null>(null);
  const [accountUsername, setAccountUsername] = useState('');
  const [connecting, setConnecting] = useState(false);

  const platformConfig = {
    facebook: {
      name: 'Facebook',
      icon: Facebook,
      bgColor: 'bg-violet-500',
      hoverColor: 'hover:bg-violet-600',
      loginUrl: 'https://www.facebook.com/',
      placeholder: 'Enter your Facebook email or username',
    },
    instagram: {
      name: 'Instagram',
      icon: Instagram,
      bgColor: 'bg-gradient-to-r from-purple-500 to-pink-500',
      hoverColor: 'hover:from-purple-600 hover:to-pink-600',
      loginUrl: 'https://www.instagram.com/',
      placeholder: 'Enter your Instagram username (e.g., @username)',
    },
    linkedin: {
      name: 'LinkedIn',
      icon: Linkedin,
      bgColor: 'bg-violet-700',
      hoverColor: 'hover:bg-violet-800',
      loginUrl: 'https://www.linkedin.com/login?fromSignIn=true&trk=guest_homepage-basic_nav-header-signin',
      placeholder: 'Enter your LinkedIn email',
    },
  };

  const getAccountStatus = (platform: Platform) => {
    const account = accounts.find(a => a.platform === platform);
    return {
      exists: !!account,
      connected: account?.is_connected || false,
      account,
    };
  };

  const handleSaveConnection = async () => {
    if (!showUsernameModal || !accountUsername.trim()) {
      alert('Please enter your account username/email');
      return;
    }

    setConnecting(true);

    try {
      const { data: existingAccount } = await supabase
        .from('social_accounts')
        .select('id')
        .eq('brand_id', brandId)
        .eq('platform', showUsernameModal)
        .maybeSingle();

      if (existingAccount) {
        await supabase
          .from('social_accounts')
          .update({
            account_name: accountUsername.trim(),
            is_connected: true,
          })
          .eq('id', existingAccount.id);
      } else {
        await supabase
          .from('social_accounts')
          .insert({
            brand_id: brandId,
            platform: showUsernameModal,
            account_name: accountUsername.trim(),
            is_connected: true,
          });
      }

      setShowUsernameModal(null);
      setAccountUsername('');
      onAccountsUpdated();
    } catch (error) {
      console.error('Error saving connection:', error);
      alert('Failed to save connection. Please try again.');
    } finally {
      setConnecting(false);
    }
  };

  const handleDisconnect = async (accountId: string) => {
    if (!confirm('Are you sure you want to disconnect this account?')) return;

    const { error } = await supabase
      .from('social_accounts')
      .update({
        is_connected: false,
        access_token: null,
        refresh_token: null,
        token_expires_at: null,
      })
      .eq('id', accountId);

    if (!error) {
      onAccountsUpdated();
    }
  };

  return (
    <div className="space-y-6">
      {(Object.keys(platformConfig) as Platform[]).map((platform) => {
        const config = platformConfig[platform];
        const status = getAccountStatus(platform);
        const Icon = config.icon;

        return (
          <div
            key={platform}
            className="bg-white rounded-xl border-2 border-gray-200 overflow-hidden shadow-sm hover:shadow-md transition"
          >
            <div className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <Icon className="w-8 h-8 text-gray-700" />
                  <div>
                    <h3 className="font-bold text-lg text-gray-900">{config.name}</h3>
                    {status.connected ? (
                      <p className="text-sm text-green-600 flex items-center gap-1">
                        <CheckCircle className="w-4 h-4" />
                        Connected {status.account?.account_name && `as ${status.account.account_name}`}
                      </p>
                    ) : (
                      <p className="text-sm text-gray-500">Not connected</p>
                    )}
                  </div>
                </div>

                {status.connected && (
                  <button
                    onClick={() => handleDisconnect(status.account!.id)}
                    className="px-4 py-2 bg-red-50 hover:bg-red-100 text-red-600 rounded-lg transition text-sm font-medium flex items-center gap-2"
                  >
                    <Trash2 className="w-4 h-4" />
                    Disconnect
                  </button>
                )}
              </div>

              {!status.connected && (
                <div className="space-y-3">
                  <div className="bg-gray-50 rounded-lg p-4 border border-gray-200">
                    <p className="text-sm text-gray-700 mb-3">
                      <strong>Step 1:</strong> Log in to {config.name}
                    </p>
                    <a
                      href={config.loginUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className={`block w-full px-6 py-3 ${config.bgColor} ${config.hoverColor} text-white rounded-lg transition font-semibold text-center shadow-md`}
                    >
                      Open {config.name} Login Page →
                    </a>
                  </div>

                  <div className="bg-gray-50 rounded-lg p-4 border border-gray-200">
                    <p className="text-sm text-gray-700 mb-3">
                      <strong>Step 2:</strong> After logging in, enter your account details
                    </p>
                    <button
                      onClick={() => {
                        setShowUsernameModal(platform);
                        setAccountUsername('');
                      }}
                      className="w-full px-6 py-3 bg-gray-700 hover:bg-gray-800 text-white rounded-lg transition font-semibold shadow-md"
                    >
                      Enter My {config.name} Details
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        );
      })}

      {showUsernameModal && (
        <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full p-8">
            <h2 className="text-3xl font-bold text-gray-900 mb-2">
              Connect {platformConfig[showUsernameModal].name}
            </h2>
            <p className="text-gray-600 mb-6">
              Enter your {platformConfig[showUsernameModal].name} account information to complete the connection.
            </p>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  {platformConfig[showUsernameModal].name} Username/Email
                </label>
                <input
                  type="text"
                  value={accountUsername}
                  onChange={(e) => setAccountUsername(e.target.value)}
                  placeholder={platformConfig[showUsernameModal].placeholder}
                  className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:ring-2 focus:ring-violet-500 focus:border-violet-500 text-base"
                  autoFocus
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && accountUsername.trim()) {
                      handleSaveConnection();
                    }
                  }}
                />
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  onClick={() => {
                    setShowUsernameModal(null);
                    setAccountUsername('');
                  }}
                  className="flex-1 px-6 py-3 bg-gray-200 hover:bg-gray-300 text-gray-800 rounded-lg transition font-semibold"
                >
                  Cancel
                </button>
                <button
                  onClick={handleSaveConnection}
                  disabled={connecting || !accountUsername.trim()}
                  className="flex-1 px-6 py-3 bg-violet-600 hover:bg-violet-700 text-white rounded-lg transition font-semibold disabled:opacity-50 disabled:cursor-not-allowed shadow-md"
                >
                  {connecting ? 'Saving...' : 'Save Connection'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
