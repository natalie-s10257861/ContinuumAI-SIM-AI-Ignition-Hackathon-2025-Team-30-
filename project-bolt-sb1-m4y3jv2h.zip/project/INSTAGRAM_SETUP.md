# Instagram OAuth Setup - Quick Start Guide

This guide will walk you through setting up Instagram OAuth authentication step-by-step.

## Important: Instagram Requirements

Instagram OAuth requires:
1. A **Facebook Developer App**
2. A **Facebook Page**
3. An **Instagram Business Account** linked to that Facebook Page

You cannot connect a personal Instagram account directly. It must be a Business account.

---

## Step 1: Create a Facebook Developer App

### 1.1 Go to Facebook Developers
Visit: [https://developers.facebook.com](https://developers.facebook.com)

### 1.2 Create a New App
1. Click **"Create App"** button
2. Select **"Business"** as the app type
3. Click **"Next"**

### 1.3 Fill in App Details
- **App Name**: Your App Name (e.g., "SocialFlow Manager")
- **App Contact Email**: Your email address
- **Business Account**: Select existing or create new (optional)
- Click **"Create App"**

### 1.4 Get Your App Credentials
1. Go to **Settings** → **Basic** in the left sidebar
2. Copy your **App ID**
3. Copy your **App Secret** (click "Show" button)
4. Save these for later!

---

## Step 2: Configure Facebook Login

### 2.1 Add Facebook Login Product
1. In your app dashboard, find **"Add Products"** section
2. Find **"Facebook Login"** and click **"Set Up"**
3. Choose **"Web"** as your platform
4. Enter your website URL: `http://localhost:5173` (for development)
5. Click **"Save"**

### 2.2 Configure OAuth Settings
1. Go to **Facebook Login** → **Settings** in the left sidebar
2. Under **"Valid OAuth Redirect URIs"**, add:
   - Development: `http://localhost:5173/oauth/callback`
   - Production: `https://yourdomain.com/oauth/callback`
3. Click **"Save Changes"**

---

## Step 3: Request Instagram Permissions

### 3.1 Add Instagram Graph API
1. Go to **"Add Products"** section
2. Find **"Instagram"** product and click **"Set Up"**

### 3.2 Request Permissions
1. Go to **App Review** → **Permissions and Features**
2. Search for and request these permissions:
   - `pages_show_list` - View your Facebook Pages
   - `pages_read_engagement` - Read Page engagement data
   - `pages_manage_posts` - Manage Page posts
   - `instagram_basic` - Access Instagram account info
   - `instagram_content_publish` - Publish content to Instagram

**Note**: Some permissions require app review by Facebook, but you can test with your own accounts immediately.

---

## Step 4: Link Instagram to Facebook Page

### 4.1 Convert to Instagram Business Account
1. Open Instagram app on your phone
2. Go to **Settings** → **Account**
3. Tap **"Switch to Professional Account"**
4. Choose **"Business"**
5. Complete the setup

### 4.2 Link to Facebook Page
1. In Instagram, go to **Settings** → **Account**
2. Tap **"Linked Accounts"** or **"Page"**
3. Tap **"Facebook"**
4. Select the Facebook Page to link
5. Confirm the connection

**Important**: The Facebook Page you select must be one you admin!

---

## Step 5: Configure Your App

### 5.1 Update .env File
Open your `.env` file and add your credentials:

```env
# Facebook App Credentials (also used for Instagram)
VITE_FACEBOOK_APP_ID=your_app_id_from_step_1.4
VITE_FACEBOOK_APP_SECRET=your_app_secret_from_step_1.4

# Instagram uses same Facebook App ID
VITE_INSTAGRAM_APP_ID=your_app_id_from_step_1.4
```

### 5.2 Restart Dev Server
After updating .env, restart your development server:
```bash
npm run dev
```

---

## Step 6: Test Instagram Connection

### 6.1 Connect Instagram
1. Go to your app
2. Click **Settings** (gear icon)
3. Click **"Manage Connections"**
4. Click **"Connect Instagram"**

### 6.2 Authorize the App
1. A popup window will open
2. Log in to Facebook (if not already)
3. Select the Facebook Page that's linked to Instagram
4. Grant the requested permissions
5. Window will close automatically on success

### 6.3 Verify Connection
- Instagram should show as "Connected" with a green checkmark
- Your Instagram username should be displayed

---

## Common Issues and Solutions

### Issue: "No Instagram Business account found"
**Solution**:
- Make sure your Instagram account is a Business account (not Personal)
- Verify the Instagram account is properly linked to your Facebook Page
- Try unlinking and relinking in Instagram settings

### Issue: "No Facebook Pages found"
**Solution**:
- You need to create a Facebook Page first
- Visit: [https://www.facebook.com/pages/create](https://www.facebook.com/pages/create)
- Create a page, then link your Instagram Business account to it

### Issue: "Invalid OAuth redirect URI"
**Solution**:
- Double-check the redirect URI in Facebook App settings
- It must exactly match: `http://localhost:5173/oauth/callback`
- No trailing slash, exact protocol (http vs https)

### Issue: "This app is not approved"
**Solution**:
- During development, you can test with accounts that have a role in the app
- Go to **Roles** → **Roles** in Facebook App dashboard
- Add test users, developers, or admins
- Submit for App Review before going live

### Issue: "Permission denied"
**Solution**:
- Check that you requested all required permissions in App Review
- Wait for Facebook to approve advanced permissions
- For testing, permissions like `instagram_content_publish` work immediately for app admins

---

## Testing Publishing to Instagram

### Requirements for Instagram Posts
- Instagram **requires an image** (text-only posts not supported)
- Image must be publicly accessible URL
- Recommended image size: 1080x1080px (square)
- Supported formats: JPG, PNG

### Test a Post
1. Create a new post in your app
2. Add an image URL
3. Write your caption
4. Select Instagram as platform
5. Click **"Publish Ready Posts"**
6. Select Instagram
7. Click **"Publish"**

---

## App Review (For Production)

### Before Going Live
1. Complete Facebook App Review for required permissions
2. Provide detailed use cases for each permission
3. Record a video showing your app's functionality
4. Update privacy policy and terms of service URLs
5. Set app to "Live" mode in Facebook dashboard

### Required Documentation
- Privacy Policy URL
- Terms of Service URL
- App Icon (1024x1024px)
- Screencast showing permission usage

---

## Production Checklist

- [ ] Facebook App created and configured
- [ ] Instagram Business account created and linked to Facebook Page
- [ ] All required permissions approved by Facebook
- [ ] OAuth redirect URIs updated for production domain
- [ ] Environment variables set with production credentials
- [ ] SSL/HTTPS enabled on production domain
- [ ] App set to "Live" mode in Facebook
- [ ] Privacy policy and terms published

---

## Additional Resources

- [Facebook for Developers](https://developers.facebook.com)
- [Instagram Graph API Documentation](https://developers.facebook.com/docs/instagram-api)
- [Instagram Business Account Setup](https://help.instagram.com/502981923235522)
- [Facebook App Review Process](https://developers.facebook.com/docs/app-review)

---

## Support

If you encounter issues:
1. Check Facebook App dashboard for error messages
2. Review Instagram Business account settings
3. Verify Facebook Page and Instagram account are properly linked
4. Check browser console for detailed error messages
5. Review Facebook Developer documentation

For app-specific issues, check the browser console and network tab for detailed error messages.
