# Social Media Publishing Guide

## Quick Start: How to Publish Posts

### Step 1: Connect Your Social Media Accounts

1. Click the **Settings** icon (gear) in the top right
2. Under "Social Media Connections", you'll see Facebook, Instagram, and LinkedIn
3. For each platform you want to connect:
   - Click the **"Open [Platform] Login"** button
   - This opens the social media login page in a new tab
   - Log into your account there
   - Return to SocialFlow
   - Click **"Enter My [Platform] Details"**
   - Enter your username/email
   - Click **"Save Connection"**

Your account is now connected and will show a green checkmark!

### Step 2: Create a Post

1. Click **"Create New Post"** on the dashboard
2. Fill in:
   - **Title**: Name your post (for internal tracking)
   - **Content**: Write your post content
   - **Scheduled Date**: Choose when to publish (must be current time or past to publish immediately)
   - **Image** (optional): Upload an image
   - **Hashtags** (optional): Add hashtags or use AI to generate them

3. Click **"Schedule Post"** to save it

### Step 3: Publish Your Posts

1. Make sure your post's scheduled date is **now or in the past**
2. Click the green **"Publish Ready Posts"** button in the top menu
3. A modal will appear showing:
   - Your connected platforms (select which ones to publish to)
   - Your ready posts (select which ones to publish)
4. Click **"Publish to [X] Platforms"**
5. Wait for the results - you'll see which posts were successfully published!

## Important Notes

- **Connected Accounts Required**: You must connect at least one social media account before publishing
- **Scheduled Time**: Posts can only be published if their scheduled date/time has passed
- **Multiple Platforms**: You can publish the same post to multiple platforms at once
- **Status Updates**: After publishing, posts will show as "Published" with a timestamp

## Current Publishing System

The current version uses a simplified connection system:
- No OAuth configuration needed
- Direct HTML links to social media login pages
- Manual account registration by username/email
- Publishing is simulated in demo mode (console logs show what would be published)

To enable **real publishing** to social media platforms, you would need to:
1. Set up OAuth apps on each platform's developer portal
2. Configure OAuth credentials in Supabase Edge Functions
3. Implement the full OAuth flow with access tokens
4. The publishing API calls will then actually post to social media

## Troubleshooting

**"No Connected Accounts" Error**
- Make sure you've completed Step 1 and connected at least one account

**"No Posts Ready" Error**
- Check that your post's scheduled date is in the past or present
- The scheduled date must be earlier than the current time

**Post Not Appearing**
- Refresh the page after creating a post
- Check that you clicked "Schedule Post" (not just "Save Draft")

## Demo Mode

Currently, the app operates in **demo mode** for publishing:
- All publish actions are logged to the browser console
- Posts are marked as "published" in the database
- No actual posts are made to social media platforms
- This allows you to test the full workflow without API credentials
