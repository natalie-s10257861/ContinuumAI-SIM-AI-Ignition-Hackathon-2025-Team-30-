# OAuth Integration Setup Guide

This guide walks you through setting up OAuth authentication for Facebook, Instagram, and LinkedIn.

## Overview

The application now supports connecting social media accounts via OAuth, allowing you to publish directly to:
- **Facebook Pages**
- **Instagram Business Accounts** (via Facebook)
- **LinkedIn Pages/Profiles**

## Prerequisites

You'll need developer accounts for each platform you want to integrate.

## 1. Facebook & Instagram Setup

Facebook and Instagram use the same app and OAuth flow.

### Create a Facebook App

1. Go to [Facebook Developers](https://developers.facebook.com)
2. Click "Create App"
3. Select "Business" as the app type
4. Fill in your app details:
   - App Name: Your Application Name
   - App Contact Email: Your email
   - Business Account: Select or create one

### Configure Facebook Login

1. In your app dashboard, click "Add Products"
2. Find "Facebook Login" and click "Set Up"
3. Choose "Web" as the platform
4. Enter your site URL: `http://localhost:5173` (for development)

### Add Required Permissions

Go to "App Review" > "Permissions and Features" and request:
- `pages_show_list`
- `pages_read_engagement`
- `pages_manage_posts`
- `pages_manage_metadata`
- `instagram_basic` (for Instagram)
- `instagram_content_publish` (for Instagram)

### Get Your App Credentials

1. Go to Settings > Basic
2. Copy your **App ID**
3. Add to `.env`: `VITE_FACEBOOK_APP_ID=your_app_id_here`

### Configure OAuth Redirect URIs

1. Go to Facebook Login > Settings
2. Add Valid OAuth Redirect URIs:
   - Development: `http://localhost:5173/oauth/callback`
   - Production: `https://yourdomain.com/oauth/callback`

## 2. LinkedIn Setup

### Create a LinkedIn App

1. Go to [LinkedIn Developers](https://www.linkedin.com/developers)
2. Click "Create App"
3. Fill in your app details:
   - App Name: Your Application Name
   - LinkedIn Page: Select or create a company page
   - App Logo: Upload a logo (required)
   - Legal Agreement: Check and accept

### Add Products

1. In your app, go to "Products" tab
2. Request access to:
   - "Share on LinkedIn"
   - "Sign In with LinkedIn"

### Configure OAuth

1. Go to "Auth" tab
2. Add Redirect URLs:
   - Development: `http://localhost:5173/oauth/callback`
   - Production: `https://yourdomain.com/oauth/callback`

### Get Your Credentials

1. In the "Auth" tab, find your credentials
2. Copy your **Client ID**
3. Add to `.env`: `VITE_LINKEDIN_CLIENT_ID=your_client_id_here`

## 3. Environment Variables

Create or update your `.env` file with:

```env
# Facebook OAuth
VITE_FACEBOOK_APP_ID=your_facebook_app_id

# Instagram OAuth (uses Facebook App ID)
VITE_INSTAGRAM_APP_ID=your_facebook_app_id

# LinkedIn OAuth
VITE_LINKEDIN_CLIENT_ID=your_linkedin_client_id
```

## 4. OAuth Callback Handler

Create a callback handler page at `/oauth/callback` to handle the OAuth redirect. The component `SocialAccountConnect` handles the popup-based OAuth flow.

### How It Works

1. User clicks "Connect [Platform]" button
2. OAuth popup window opens with platform's login
3. User authorizes the app
4. Platform redirects to `/oauth/callback` with authorization code
5. Your app exchanges the code for an access token
6. Token is securely stored in the database
7. Account is marked as connected

## 5. Testing OAuth Flow

### Development Testing

1. Start your dev server: `npm run dev`
2. Go to Settings/Brand Setup
3. Click "Manage Connections"
4. Click "Connect [Platform]"
5. Complete OAuth flow in popup
6. Verify account shows as "Connected"

### Production Deployment

1. Update OAuth redirect URIs in all platform developer consoles
2. Update environment variables with production values
3. Ensure your domain is HTTPS (required by OAuth providers)
4. Test the complete flow in production

## 6. Publishing Posts

Once accounts are connected, the app can publish directly:

### Facebook
- Posts text content and optional images
- Uses the Facebook Graph API
- Requires page access token

### Instagram
- Requires an image (text-only not supported)
- Uses Instagram Graph API via Facebook
- Requires Instagram Business account linked to Facebook Page

### LinkedIn
- Posts text content and optional images
- Uses LinkedIn Share API
- Supports both personal profiles and company pages

## 7. Token Management

### Token Storage
- Access tokens are stored in `social_accounts.access_token`
- Refresh tokens in `social_accounts.refresh_token`
- Expiration tracked in `social_accounts.token_expires_at`

### Token Refresh
Implement token refresh logic before tokens expire:
- Facebook: 60 days (extendable)
- Instagram: Same as Facebook
- LinkedIn: 60 days

### Security
- Never expose tokens in client-side code
- Use HTTPS in production
- Consider encrypting tokens at rest
- Implement token refresh before expiration

## 8. Troubleshooting

### "OAuth not configured" error
- Verify environment variables are set correctly
- Restart dev server after adding .env variables

### "Invalid redirect URI" error
- Check redirect URIs in platform developer consoles
- Ensure exact match including protocol and trailing slashes

### "Permission denied" error
- Verify all required permissions are approved
- Some permissions require app review by the platform

### Token expired
- Implement token refresh logic
- Reconnect the account manually

## 9. Going Live

### Before Launch Checklist

- [ ] All OAuth apps are in production mode
- [ ] Redirect URIs updated for production domain
- [ ] Environment variables set in production
- [ ] App review completed for required permissions
- [ ] Token refresh logic implemented
- [ ] Error handling and user feedback in place
- [ ] HTTPS enabled on production domain

## Support

For platform-specific issues:
- [Facebook Developer Docs](https://developers.facebook.com/docs)
- [Instagram API Docs](https://developers.facebook.com/docs/instagram-api)
- [LinkedIn API Docs](https://docs.microsoft.com/en-us/linkedin/)
