import { createClient } from 'npm:@supabase/supabase-js@2.39.0';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Client-Info, Apikey',
};

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const now = new Date();
    const fiveMinutesFromNow = new Date(now.getTime() + 5 * 60000);

    const { data: posts, error: fetchError } = await supabase
      .from('content_posts')
      .select('*, post_variants(*)')
      .eq('status', 'scheduled')
      .lte('scheduled_date', fiveMinutesFromNow.toISOString())
      .gte('scheduled_date', now.toISOString());

    if (fetchError) throw fetchError;

    if (!posts || posts.length === 0) {
      return new Response(
        JSON.stringify({
          success: true,
          message: 'No posts to publish at this time',
          processed: 0,
        }),
        {
          headers: {
            ...corsHeaders,
            'Content-Type': 'application/json',
          },
        }
      );
    }

    const results = [];

    for (const post of posts) {
      const { data: approval } = await supabase
        .from('post_approvals')
        .select('status')
        .eq('post_id', post.id)
        .eq('status', 'approved')
        .maybeSingle();

      if (!approval) {
        results.push({
          post_id: post.id,
          status: 'skipped',
          reason: 'Not approved',
        });
        continue;
      }

      const variantUpdates = post.post_variants.map((variant: any) => ({
        id: variant.id,
        status: 'published',
        published_at: now.toISOString(),
      }));

      if (variantUpdates.length > 0) {
        for (const update of variantUpdates) {
          await supabase
            .from('post_variants')
            .update({ status: update.status, published_at: update.published_at })
            .eq('id', update.id);
        }
      }

      await supabase
        .from('content_posts')
        .update({ status: 'published' })
        .eq('id', post.id);

      results.push({
        post_id: post.id,
        status: 'published',
        variants_published: variantUpdates.length,
      });
    }

    return new Response(
      JSON.stringify({
        success: true,
        message: `Successfully processed ${results.length} posts`,
        results,
        processed: results.length,
      }),
      {
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  } catch (error: any) {
    console.error('Error in auto-publish-posts:', error);
    return new Response(
      JSON.stringify({
        success: false,
        error: error.message,
      }),
      {
        status: 500,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  }
});