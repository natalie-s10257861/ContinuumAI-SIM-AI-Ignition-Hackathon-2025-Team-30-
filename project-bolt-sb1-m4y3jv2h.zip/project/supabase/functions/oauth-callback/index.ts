import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "jsr:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const { code, state, platform } = await req.json();

    if (!code || !state || !platform) {
      throw new Error("Missing required parameters");
    }

    const stateData = JSON.parse(atob(state));
    const { brandId } = stateData;

    const redirectUri = `${req.headers.get('origin')}/oauth/callback`;

    let accessToken: string | null = null;
    let refreshToken: string | null = null;
    let expiresIn: number | null = null;
    let pageId: string | null = null;
    let accountName: string | null = null;
    let accountUsername: string | null = null;

    if (platform === 'facebook' || platform === 'instagram') {
      const clientId = Deno.env.get('FACEBOOK_APP_ID');
      const clientSecret = Deno.env.get('FACEBOOK_APP_SECRET');

      if (!clientId || !clientSecret) {
        throw new Error('Facebook credentials not configured');
      }

      const tokenResponse = await fetch(
        `https://graph.facebook.com/v18.0/oauth/access_token?` +
        `client_id=${clientId}&` +
        `client_secret=${clientSecret}&` +
        `redirect_uri=${encodeURIComponent(redirectUri)}&` +
        `code=${code}`
      );

      const tokenData = await tokenResponse.json();

      if (tokenData.error) {
        throw new Error(tokenData.error.message);
      }

      accessToken = tokenData.access_token;
      expiresIn = tokenData.expires_in;

      const longLivedResponse = await fetch(
        `https://graph.facebook.com/v18.0/oauth/access_token?` +
        `grant_type=fb_exchange_token&` +
        `client_id=${clientId}&` +
        `client_secret=${clientSecret}&` +
        `fb_exchange_token=${accessToken}`
      );

      const longLivedData = await longLivedResponse.json();
      if (!longLivedData.error) {
        accessToken = longLivedData.access_token;
        expiresIn = longLivedData.expires_in;
      }

      const meResponse = await fetch(
        `https://graph.facebook.com/v18.0/me?fields=id,name,accounts{id,name,access_token,instagram_business_account}&access_token=${accessToken}`
      );
      const meData = await meResponse.json();

      if (platform === 'facebook') {
        if (meData.accounts?.data && meData.accounts.data.length > 0) {
          const page = meData.accounts.data[0];
          pageId = page.id;
          accountName = page.name;
          accessToken = page.access_token;
        } else {
          accountName = meData.name;
          pageId = meData.id;
        }
      } else if (platform === 'instagram') {
        if (meData.accounts?.data && meData.accounts.data.length > 0) {
          const page = meData.accounts.data[0];
          if (page.instagram_business_account) {
            pageId = page.instagram_business_account.id;
            const igResponse = await fetch(
              `https://graph.facebook.com/v18.0/${pageId}?fields=username,name&access_token=${page.access_token}`
            );
            const igData = await igResponse.json();
            accountName = igData.name || igData.username;
            accountUsername = igData.username;
            accessToken = page.access_token;
          } else {
            throw new Error('No Instagram Business account found');
          }
        } else {
          throw new Error('No Facebook Pages found');
        }
      }
    } else if (platform === 'linkedin') {
      const clientId = Deno.env.get('LINKEDIN_CLIENT_ID');
      const clientSecret = Deno.env.get('LINKEDIN_CLIENT_SECRET');

      if (!clientId || !clientSecret) {
        throw new Error('LinkedIn credentials not configured');
      }

      const tokenResponse = await fetch('https://www.linkedin.com/oauth/v2/accessToken', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: new URLSearchParams({
          grant_type: 'authorization_code',
          code,
          redirect_uri: redirectUri,
          client_id: clientId,
          client_secret: clientSecret,
        }),
      });

      const tokenData = await tokenResponse.json();

      if (tokenData.error) {
        throw new Error(tokenData.error_description || tokenData.error);
      }

      accessToken = tokenData.access_token;
      refreshToken = tokenData.refresh_token;
      expiresIn = tokenData.expires_in;

      const profileResponse = await fetch('https://api.linkedin.com/v2/me', {
        headers: {
          'Authorization': `Bearer ${accessToken}`,
        },
      });

      const profileData = await profileResponse.json();
      pageId = profileData.id;
      accountName = `${profileData.localizedFirstName} ${profileData.localizedLastName}`;
    }

    if (!accessToken) {
      throw new Error('Failed to obtain access token');
    }

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const expiresAt = expiresIn
      ? new Date(Date.now() + expiresIn * 1000).toISOString()
      : null;

    const { data: existingAccount } = await supabase
      .from('social_accounts')
      .select('id')
      .eq('brand_id', brandId)
      .eq('platform', platform)
      .maybeSingle();

    if (existingAccount) {
      await supabase
        .from('social_accounts')
        .update({
          access_token: accessToken,
          refresh_token: refreshToken,
          token_expires_at: expiresAt,
          page_id: pageId,
          account_name: accountName || `${platform} Account`,
          account_username: accountUsername,
          is_connected: true,
          oauth_provider: platform,
        })
        .eq('id', existingAccount.id);
    } else {
      await supabase
        .from('social_accounts')
        .insert({
          brand_id: brandId,
          platform,
          access_token: accessToken,
          refresh_token: refreshToken,
          token_expires_at: expiresAt,
          page_id: pageId,
          account_name: accountName || `${platform} Account`,
          account_username: accountUsername,
          is_connected: true,
          oauth_provider: platform,
        });
    }

    return new Response(
      JSON.stringify({
        success: true,
        accountName,
        accountUsername,
      }),
      {
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 400,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  }
});