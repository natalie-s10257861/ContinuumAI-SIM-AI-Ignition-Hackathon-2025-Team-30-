import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const { platform, brandId } = await req.json();

    if (!platform || !brandId) {
      throw new Error("Missing required parameters");
    }

    const redirectUri = `${req.headers.get('origin')}/oauth/callback`;
    const state = btoa(JSON.stringify({ brandId, platform }));

    let authUrl: string;
    let clientId: string;

    switch (platform) {
      case 'facebook':
      case 'instagram':
        clientId = Deno.env.get('FACEBOOK_APP_ID') || '';
        if (!clientId) {
          throw new Error('Facebook App ID not configured');
        }
        authUrl = `https://www.facebook.com/v18.0/dialog/oauth?` +
          `client_id=${clientId}&` +
          `redirect_uri=${encodeURIComponent(redirectUri)}&` +
          `scope=pages_show_list,pages_read_engagement,pages_manage_posts,pages_manage_metadata,instagram_basic,instagram_content_publish&` +
          `response_type=code&` +
          `state=${state}`;
        break;

      case 'linkedin':
        clientId = Deno.env.get('LINKEDIN_CLIENT_ID') || '';
        if (!clientId) {
          throw new Error('LinkedIn Client ID not configured');
        }
        authUrl = `https://www.linkedin.com/oauth/v2/authorization?` +
          `client_id=${clientId}&` +
          `redirect_uri=${encodeURIComponent(redirectUri)}&` +
          `scope=w_member_social,r_liteprofile&` +
          `response_type=code&` +
          `state=${state}`;
        break;

      default:
        throw new Error(`Unsupported platform: ${platform}`);
    }

    return new Response(
      JSON.stringify({ authUrl }),
      {
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 400,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  }
});