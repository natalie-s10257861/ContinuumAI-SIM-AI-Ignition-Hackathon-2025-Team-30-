/*
  # Add Content Planning and Approval Features

  ## Overview
  This migration extends the schema to support AI-powered content planning,
  approval workflows, hashtag optimization, and performance tracking.

  ## New Tables

  ### 1. `content_plans`
  - `id` (uuid, primary key) - Unique plan identifier
  - `brand_id` (uuid, foreign key) - Associated brand
  - `month` (integer) - Month (1-12)
  - `year` (integer) - Year
  - `themes` (jsonb) - AI-generated themes and topics
  - `suggested_posts` (jsonb) - AI-suggested post ideas with dates
  - `created_at` (timestamptz) - Creation timestamp
  - `updated_at` (timestamptz) - Last update timestamp

  ### 2. `post_approvals`
  - `id` (uuid, primary key) - Unique approval identifier
  - `post_id` (uuid, foreign key) - Associated post
  - `status` (text) - pending, approved, rejected, needs_changes
  - `reviewer_notes` (text, nullable) - Feedback/notes
  - `approved_at` (timestamptz, nullable) - Approval timestamp
  - `created_at` (timestamptz) - Creation timestamp

  ### 3. `hashtag_sets`
  - `id` (uuid, primary key) - Unique set identifier
  - `brand_id` (uuid, foreign key) - Associated brand
  - `name` (text) - Hashtag set name
  - `hashtags` (jsonb) - Array of hashtags
  - `platform` (text) - Target platform
  - `category` (text, nullable) - Category/theme
  - `created_at` (timestamptz) - Creation timestamp

  ### 4. `post_performance`
  - `id` (uuid, primary key) - Unique record identifier
  - `post_variant_id` (uuid, foreign key) - Associated variant
  - `likes` (integer) - Like count
  - `comments` (integer) - Comment count
  - `shares` (integer) - Share count
  - `reach` (integer) - Reach count
  - `engagement_rate` (decimal) - Engagement rate percentage
  - `tracked_at` (timestamptz) - When metrics were recorded
  - `created_at` (timestamptz) - Record creation

  ## Updates to Existing Tables

  ### `content_posts` additions
  - `requires_approval` (boolean) - Whether post needs approval
  - `hashtags` (jsonb) - Hashtags for the post

  ### `brands` additions
  - `content_pillars` (jsonb) - Brand content themes/pillars
  - `posting_frequency` (jsonb) - Target frequency per platform

  ## Security
  - Enable RLS on all new tables
  - Same ownership model through brand_id relationship

  ## Notes
  - Content plans help with strategic planning and consistency
  - Approval workflow adds human validation before publishing
  - Hashtag optimization improves discoverability
  - Performance tracking enables data-driven decisions
*/

-- Add columns to existing brands table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'brands' AND column_name = 'content_pillars'
  ) THEN
    ALTER TABLE brands ADD COLUMN content_pillars jsonb DEFAULT '[]'::jsonb;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'brands' AND column_name = 'posting_frequency'
  ) THEN
    ALTER TABLE brands ADD COLUMN posting_frequency jsonb DEFAULT '{"twitter": 5, "linkedin": 3, "instagram": 4, "facebook": 3}'::jsonb;
  END IF;
END $$;

-- Add columns to existing content_posts table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'content_posts' AND column_name = 'requires_approval'
  ) THEN
    ALTER TABLE content_posts ADD COLUMN requires_approval boolean DEFAULT true;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'content_posts' AND column_name = 'hashtags'
  ) THEN
    ALTER TABLE content_posts ADD COLUMN hashtags jsonb DEFAULT '[]'::jsonb;
  END IF;
END $$;

-- Create content_plans table
CREATE TABLE IF NOT EXISTS content_plans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  brand_id uuid NOT NULL REFERENCES brands(id) ON DELETE CASCADE,
  month integer NOT NULL CHECK (month >= 1 AND month <= 12),
  year integer NOT NULL CHECK (year >= 2020 AND year <= 2100),
  themes jsonb DEFAULT '[]'::jsonb,
  suggested_posts jsonb DEFAULT '[]'::jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(brand_id, month, year)
);

ALTER TABLE content_plans ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own content plans"
  ON content_plans FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM brands
      WHERE brands.id = content_plans.brand_id
      AND brands.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can create own content plans"
  ON content_plans FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM brands
      WHERE brands.id = content_plans.brand_id
      AND brands.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can update own content plans"
  ON content_plans FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM brands
      WHERE brands.id = content_plans.brand_id
      AND brands.user_id = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM brands
      WHERE brands.id = content_plans.brand_id
      AND brands.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can delete own content plans"
  ON content_plans FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM brands
      WHERE brands.id = content_plans.brand_id
      AND brands.user_id = auth.uid()
    )
  );

-- Create post_approvals table
CREATE TABLE IF NOT EXISTS post_approvals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id uuid NOT NULL REFERENCES content_posts(id) ON DELETE CASCADE,
  status text DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected', 'needs_changes')),
  reviewer_notes text,
  approved_at timestamptz,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE post_approvals ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own post approvals"
  ON post_approvals FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM content_posts
      JOIN brands ON brands.id = content_posts.brand_id
      WHERE content_posts.id = post_approvals.post_id
      AND brands.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can create own post approvals"
  ON post_approvals FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM content_posts
      JOIN brands ON brands.id = content_posts.brand_id
      WHERE content_posts.id = post_approvals.post_id
      AND brands.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can update own post approvals"
  ON post_approvals FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM content_posts
      JOIN brands ON brands.id = content_posts.brand_id
      WHERE content_posts.id = post_approvals.post_id
      AND brands.user_id = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM content_posts
      JOIN brands ON brands.id = content_posts.brand_id
      WHERE content_posts.id = post_approvals.post_id
      AND brands.user_id = auth.uid()
    )
  );

-- Create hashtag_sets table
CREATE TABLE IF NOT EXISTS hashtag_sets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  brand_id uuid NOT NULL REFERENCES brands(id) ON DELETE CASCADE,
  name text NOT NULL,
  hashtags jsonb NOT NULL DEFAULT '[]'::jsonb,
  platform text NOT NULL CHECK (platform IN ('twitter', 'linkedin', 'instagram', 'facebook', 'all')),
  category text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE hashtag_sets ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own hashtag sets"
  ON hashtag_sets FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM brands
      WHERE brands.id = hashtag_sets.brand_id
      AND brands.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can create own hashtag sets"
  ON hashtag_sets FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM brands
      WHERE brands.id = hashtag_sets.brand_id
      AND brands.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can update own hashtag sets"
  ON hashtag_sets FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM brands
      WHERE brands.id = hashtag_sets.brand_id
      AND brands.user_id = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM brands
      WHERE brands.id = hashtag_sets.brand_id
      AND brands.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can delete own hashtag sets"
  ON hashtag_sets FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM brands
      WHERE brands.id = hashtag_sets.brand_id
      AND brands.user_id = auth.uid()
    )
  );

-- Create post_performance table
CREATE TABLE IF NOT EXISTS post_performance (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  post_variant_id uuid NOT NULL REFERENCES post_variants(id) ON DELETE CASCADE,
  likes integer DEFAULT 0,
  comments integer DEFAULT 0,
  shares integer DEFAULT 0,
  reach integer DEFAULT 0,
  engagement_rate decimal(5,2) DEFAULT 0.00,
  tracked_at timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now()
);

ALTER TABLE post_performance ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own post performance"
  ON post_performance FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM post_variants
      JOIN content_posts ON content_posts.id = post_variants.post_id
      JOIN brands ON brands.id = content_posts.brand_id
      WHERE post_variants.id = post_performance.post_variant_id
      AND brands.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can create own post performance"
  ON post_performance FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM post_variants
      JOIN content_posts ON content_posts.id = post_variants.post_id
      JOIN brands ON brands.id = content_posts.brand_id
      WHERE post_variants.id = post_performance.post_variant_id
      AND brands.user_id = auth.uid()
    )
  );

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_content_plans_brand_id ON content_plans(brand_id);
CREATE INDEX IF NOT EXISTS idx_post_approvals_post_id ON post_approvals(post_id);
CREATE INDEX IF NOT EXISTS idx_post_approvals_status ON post_approvals(status);
CREATE INDEX IF NOT EXISTS idx_hashtag_sets_brand_id ON hashtag_sets(brand_id);
CREATE INDEX IF NOT EXISTS idx_post_performance_post_variant_id ON post_performance(post_variant_id);