/*
  # Social Media Management Platform Schema

  ## Overview
  This migration creates the complete database schema for a social media management platform
  with content calendar, AI copywriting, asset management, and multi-platform scheduling.

  ## New Tables

  ### 1. `brands`
  - `id` (uuid, primary key) - Unique brand identifier
  - `name` (text) - Brand name
  - `logo_url` (text, nullable) - Brand logo URL
  - `brand_colors` (jsonb) - Brand color palette {primary, secondary, accent}
  - `brand_voice` (text, nullable) - Description of brand voice for AI copywriting
  - `created_at` (timestamptz) - Record creation timestamp
  - `user_id` (uuid) - Owner of the brand

  ### 2. `social_accounts`
  - `id` (uuid, primary key) - Unique account identifier
  - `brand_id` (uuid, foreign key) - Associated brand
  - `platform` (text) - Platform name (twitter, linkedin, instagram, facebook)
  - `account_name` (text) - Social media account handle/name
  - `is_connected` (boolean) - Connection status
  - `created_at` (timestamptz) - Record creation timestamp

  ### 3. `content_posts`
  - `id` (uuid, primary key) - Unique post identifier
  - `brand_id` (uuid, foreign key) - Associated brand
  - `title` (text) - Post title/description
  - `content` (text) - Post copy/content
  - `scheduled_date` (timestamptz) - When to publish
  - `status` (text) - draft, scheduled, published, failed
  - `created_at` (timestamptz) - Record creation timestamp
  - `updated_at` (timestamptz) - Last update timestamp

  ### 4. `post_assets`
  - `id` (uuid, primary key) - Unique asset identifier
  - `post_id` (uuid, foreign key) - Associated post
  - `asset_url` (text) - URL to the asset
  - `asset_type` (text) - image, video, gif
  - `original_filename` (text, nullable) - Original file name
  - `created_at` (timestamptz) - Record creation timestamp

  ### 5. `post_variants`
  - `id` (uuid, primary key) - Unique variant identifier
  - `post_id` (uuid, foreign key) - Associated post
  - `social_account_id` (uuid, foreign key) - Target social account
  - `platform` (text) - Platform name
  - `content` (text) - Platform-specific content
  - `asset_url` (text, nullable) - Platform-optimized asset URL
  - `status` (text) - pending, published, failed
  - `published_at` (timestamptz, nullable) - Actual publish timestamp
  - `created_at` (timestamptz) - Record creation timestamp

  ### 6. `ai_copy_history`
  - `id` (uuid, primary key) - Unique history entry
  - `brand_id` (uuid, foreign key) - Associated brand
  - `prompt` (text) - User's prompt
  - `generated_content` (text) - AI-generated copy
  - `platform` (text, nullable) - Target platform
  - `created_at` (timestamptz) - Generation timestamp

  ## Security
  - Enable RLS on all tables
  - Authenticated users can only access their own brand data
  - Policies check ownership through brand_id -> user_id relationship

  ## Notes
  - Platform-specific optimizations handled through post_variants
  - Asset resizing metadata can be stored in asset_url or extended with jsonb
  - AI copy history enables learning user preferences over time
*/

-- Create brands table
CREATE TABLE IF NOT EXISTS brands (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  logo_url text,
  brand_colors jsonb DEFAULT '{"primary": "#000000", "secondary": "#ffffff", "accent": "#0066cc"}'::jsonb,
  brand_voice text,
  created_at timestamptz DEFAULT now(),
  user_id uuid NOT NULL
);

ALTER TABLE brands ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own brands"
  ON brands FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create own brands"
  ON brands FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own brands"
  ON brands FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own brands"
  ON brands FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create social_accounts table
CREATE TABLE IF NOT EXISTS social_accounts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  brand_id uuid NOT NULL REFERENCES brands(id) ON DELETE CASCADE,
  platform text NOT NULL CHECK (platform IN ('twitter', 'linkedin', 'instagram', 'facebook')),
  account_name text NOT NULL,
  is_connected boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE social_accounts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own social accounts"
  ON social_accounts FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM brands
      WHERE brands.id = social_accounts.brand_id
      AND brands.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can create own social accounts"
  ON social_accounts FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM brands
      WHERE brands.id = social_accounts.brand_id
      AND brands.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can update own social accounts"
  ON social_accounts FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM brands
      WHERE brands.id = social_accounts.brand_id
      AND brands.user_id = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM brands
      WHERE brands.id = social_accounts.brand_id
      AND brands.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can delete own social accounts"
  ON social_accounts FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM brands
      WHERE brands.id = social_accounts.brand_id
      AND brands.user_id = auth.uid()
    )
  );

-- Create content_posts table
CREATE TABLE IF NOT EXISTS content_posts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  brand_id uuid NOT NULL REFERENCES brands(id) ON DELETE CASCADE,
  title text NOT NULL,
  content text NOT NULL,
  scheduled_date timestamptz NOT NULL,
  status text DEFAULT 'draft' CHECK (status IN ('draft', 'scheduled', 'published', 'failed')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE content_posts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own posts"
  ON content_posts FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM brands
      WHERE brands.id = content_posts.brand_id
      AND brands.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can create own posts"
  ON content_posts FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM brands
      WHERE brands.id = content_posts.brand_id
      AND brands.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can update own posts"
  ON content_posts FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM brands
      WHERE brands.id = content_posts.brand_id
      AND brands.user_id = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM brands
      WHERE brands.id = content_posts.brand_id
      AND brands.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can delete own posts"
  ON content_posts FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM brands
      WHERE brands.id = content_posts.brand_id
      AND brands.user_id = auth.uid()
    )
  );

-- Create post_assets table
CREATE TABLE IF NOT EXISTS post_assets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id uuid NOT NULL REFERENCES content_posts(id) ON DELETE CASCADE,
  asset_url text NOT NULL,
  asset_type text DEFAULT 'image' CHECK (asset_type IN ('image', 'video', 'gif')),
  original_filename text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE post_assets ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own assets"
  ON post_assets FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM content_posts
      JOIN brands ON brands.id = content_posts.brand_id
      WHERE content_posts.id = post_assets.post_id
      AND brands.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can create own assets"
  ON post_assets FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM content_posts
      JOIN brands ON brands.id = content_posts.brand_id
      WHERE content_posts.id = post_assets.post_id
      AND brands.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can update own assets"
  ON post_assets FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM content_posts
      JOIN brands ON brands.id = content_posts.brand_id
      WHERE content_posts.id = post_assets.post_id
      AND brands.user_id = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM content_posts
      JOIN brands ON brands.id = content_posts.brand_id
      WHERE content_posts.id = post_assets.post_id
      AND brands.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can delete own assets"
  ON post_assets FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM content_posts
      JOIN brands ON brands.id = content_posts.brand_id
      WHERE content_posts.id = post_assets.post_id
      AND brands.user_id = auth.uid()
    )
  );

-- Create post_variants table
CREATE TABLE IF NOT EXISTS post_variants (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id uuid NOT NULL REFERENCES content_posts(id) ON DELETE CASCADE,
  social_account_id uuid NOT NULL REFERENCES social_accounts(id) ON DELETE CASCADE,
  platform text NOT NULL CHECK (platform IN ('twitter', 'linkedin', 'instagram', 'facebook')),
  content text NOT NULL,
  asset_url text,
  status text DEFAULT 'pending' CHECK (status IN ('pending', 'published', 'failed')),
  published_at timestamptz,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE post_variants ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own variants"
  ON post_variants FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM content_posts
      JOIN brands ON brands.id = content_posts.brand_id
      WHERE content_posts.id = post_variants.post_id
      AND brands.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can create own variants"
  ON post_variants FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM content_posts
      JOIN brands ON brands.id = content_posts.brand_id
      WHERE content_posts.id = post_variants.post_id
      AND brands.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can update own variants"
  ON post_variants FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM content_posts
      JOIN brands ON brands.id = content_posts.brand_id
      WHERE content_posts.id = post_variants.post_id
      AND brands.user_id = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM content_posts
      JOIN brands ON brands.id = content_posts.brand_id
      WHERE content_posts.id = post_variants.post_id
      AND brands.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can delete own variants"
  ON post_variants FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM content_posts
      JOIN brands ON brands.id = content_posts.brand_id
      WHERE content_posts.id = post_variants.post_id
      AND brands.user_id = auth.uid()
    )
  );

-- Create ai_copy_history table
CREATE TABLE IF NOT EXISTS ai_copy_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  brand_id uuid NOT NULL REFERENCES brands(id) ON DELETE CASCADE,
  prompt text NOT NULL,
  generated_content text NOT NULL,
  platform text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE ai_copy_history ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own AI history"
  ON ai_copy_history FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM brands
      WHERE brands.id = ai_copy_history.brand_id
      AND brands.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can create own AI history"
  ON ai_copy_history FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM brands
      WHERE brands.id = ai_copy_history.brand_id
      AND brands.user_id = auth.uid()
    )
  );

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_brands_user_id ON brands(user_id);
CREATE INDEX IF NOT EXISTS idx_social_accounts_brand_id ON social_accounts(brand_id);
CREATE INDEX IF NOT EXISTS idx_content_posts_brand_id ON content_posts(brand_id);
CREATE INDEX IF NOT EXISTS idx_content_posts_scheduled_date ON content_posts(scheduled_date);
CREATE INDEX IF NOT EXISTS idx_post_assets_post_id ON post_assets(post_id);
CREATE INDEX IF NOT EXISTS idx_post_variants_post_id ON post_variants(post_id);
CREATE INDEX IF NOT EXISTS idx_ai_copy_history_brand_id ON ai_copy_history(brand_id);