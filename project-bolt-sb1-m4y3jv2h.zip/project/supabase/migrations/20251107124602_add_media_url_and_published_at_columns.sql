/*
  # Add media_url and published_at columns to content_posts

  1. Changes
    - Add `media_url` column to store image/media URLs for posts
    - Add `published_at` column to track when posts were published
  
  2. Notes
    - Both columns are nullable as not all posts have media or are published
    - Uses timestamptz for published_at to store timezone information
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'content_posts' AND column_name = 'media_url'
  ) THEN
    ALTER TABLE content_posts ADD COLUMN media_url text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'content_posts' AND column_name = 'published_at'
  ) THEN
    ALTER TABLE content_posts ADD COLUMN published_at timestamptz;
  END IF;
END $$;