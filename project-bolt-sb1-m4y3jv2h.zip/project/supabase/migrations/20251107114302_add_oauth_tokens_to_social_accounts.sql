/*
  # Add OAuth Integration for Social Media Accounts

  ## Overview
  This migration adds OAuth authentication support for Facebook, Instagram, and LinkedIn accounts.
  It enables users to connect their social media accounts via official OAuth flows and securely store access tokens.

  ## Changes Made

  ### 1. Updated social_accounts table
    - Added `oauth_provider` column to identify the OAuth provider (facebook, instagram, linkedin)
    - Added `access_token` column to store encrypted OAuth access tokens
    - Added `refresh_token` column for token refresh capability
    - Added `token_expires_at` column to track token expiration
    - Added `page_id` column for Facebook/Instagram page identification
    - Added `is_connected` column to track connection status

  ## Security
    - All existing RLS policies remain in place
    - Access tokens are stored encrypted in the database
    - Only authenticated users can access their own account tokens

  ## Notes
    - Tokens should be encrypted at the application layer before storage
    - Refresh tokens enable long-term access without re-authentication
    - Connection status helps manage account health
*/

-- Add OAuth-related columns to social_accounts table
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'social_accounts' AND column_name = 'oauth_provider'
  ) THEN
    ALTER TABLE social_accounts ADD COLUMN oauth_provider text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'social_accounts' AND column_name = 'access_token'
  ) THEN
    ALTER TABLE social_accounts ADD COLUMN access_token text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'social_accounts' AND column_name = 'refresh_token'
  ) THEN
    ALTER TABLE social_accounts ADD COLUMN refresh_token text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'social_accounts' AND column_name = 'token_expires_at'
  ) THEN
    ALTER TABLE social_accounts ADD COLUMN token_expires_at timestamptz;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'social_accounts' AND column_name = 'page_id'
  ) THEN
    ALTER TABLE social_accounts ADD COLUMN page_id text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'social_accounts' AND column_name = 'is_connected'
  ) THEN
    ALTER TABLE social_accounts ADD COLUMN is_connected boolean DEFAULT false;
  END IF;
END $$;