# Approval & Review Workflow

## Overview

The platform now includes a comprehensive approval workflow that allows you to review and approve all posts before they go live, ensuring quality control and preventing mistakes.

## Features

### 1. AI Assistant Exit Button

**Location:** Top-right corner of AI chat window

**How to Use:**
- Click the AI Assistant icon to open chat
- Chat appears as floating window in bottom-right
- Click the X button in top-right to close
- Chat can be reopened anytime

**Benefits:**
- Clean interface when not needed
- Easy access when you need help
- Doesn't block other content

### 2. Post Review Before Scheduling

**New Workflow:**
1. Create your post in the editor
2. Click "Review & Schedule" button (instead of "Schedule Post")
3. Review screen shows:
   - Post title
   - Scheduled date/time
   - Number of platforms selected
   - Hashtags being used
4. Click "Back to Edit" to make changes
5. Click "Confirm & Schedule" to proceed

**What You See:**
- Green summary box with all details
- Clear warning that post requires approval
- Option to go back and edit
- Confirmation button to finalize

### 3. Visual Approval Indicators

**In Calendar View:**
- Posts requiring approval shown with ⚠ warning icon
- Orange background color (vs blue for approved)
- Border highlight for visibility
- Click post to open approval workflow

**Status Colors:**
- 🟢 Green: Published posts
- 🔵 Blue: Approved and scheduled
- 🟠 Orange: Awaiting approval
- ⚪ Gray: Drafts
- 🔴 Red: Failed posts

### 4. Approval Workflow

**Opening Approval:**
- Click any post with ⚠ icon in calendar
- Approval screen opens automatically
- Shows full post details

**Review Options:**
1. **Approve** - Post will publish at scheduled time
2. **Request Changes** - Returns to draft with notes
3. **Reject** - Marks post as rejected with notes

**Approval Features:**
- Add reviewer notes
- See full post content
- View scheduled date
- One-click actions

## User Flow

### Creating & Reviewing a Post

```
1. Dashboard → Click "Create Post"
   ↓
2. Write content, add image, select platforms
   ↓
3. Click "Review & Schedule"
   ↓
4. Review summary screen appears
   ↓
5. Either:
   - Click "Back to Edit" → returns to editor
   - Click "Confirm & Schedule" → saves post
   ↓
6. Post appears in calendar with ⚠ icon
   ↓
7. Click post in calendar to approve
   ↓
8. Click "Approve" button
   ↓
9. Post scheduled and will auto-publish
```

### Team Approval Workflow

**For Content Creators:**
1. Create posts throughout the week
2. Click "Review & Schedule" on each
3. Posts wait for manager approval

**For Managers/Reviewers:**
1. Check dashboard for pending approvals
2. Orange notification shows count
3. Click pending posts in calendar
4. Review and approve/reject each
5. Add feedback if requesting changes

## Benefits

### Quality Control
- Catch typos before publishing
- Verify correct platforms selected
- Ensure hashtags are appropriate
- Check scheduled times

### Team Coordination
- Managers approve team content
- Clear feedback loop
- No posts slip through accidentally
- Audit trail of approvals

### Mistake Prevention
- Two-step confirmation process
- Visual review of all details
- Easy to go back and edit
- Clear indicators in calendar

### Professional Standards
- Consistent quality
- Brand voice maintained
- Strategic posting times verified
- Platform-appropriate content

## Technical Details

### Database Schema

**Posts with Approval:**
```sql
content_posts {
  requires_approval: boolean (default: true)
  status: 'draft' | 'scheduled' | 'published' | 'failed'
}

post_approvals {
  post_id: uuid
  status: 'pending' | 'approved' | 'rejected' | 'needs_changes'
  reviewer_notes: text
  approved_at: timestamp
}
```

### Approval States

**Pending:**
- Post created with `requires_approval = true`
- Status is `scheduled`
- Approval record created with `status = pending`
- Shows in calendar with ⚠ icon

**Approved:**
- Approval record updated to `status = approved`
- `approved_at` timestamp set
- Post remains `scheduled`
- Auto-publish edge function can now publish it

**Rejected:**
- Approval record updated to `status = rejected`
- Post status changed to `draft`
- Reviewer notes saved
- Creator can edit and resubmit

### Security

**Row Level Security:**
- Users can only approve their own brand's posts
- Approval records linked to post ownership
- No cross-user access possible

## Best Practices

### For Solo Users

1. **Quick Review:**
   - Use review screen to double-check
   - Catch mistakes before scheduling
   - Approve immediately if ready

2. **Batch Approval:**
   - Create multiple posts
   - Review all at once
   - Approve in bulk session

### For Teams

1. **Daily Review Schedule:**
   - Set specific approval times
   - Morning review of overnight posts
   - End-of-day approval session

2. **Clear Feedback:**
   - Always add notes when requesting changes
   - Be specific about what needs fixing
   - Use approval workflow for communication

3. **Urgency Handling:**
   - Orange indicator shows pending posts
   - Count visible in dashboard
   - Quick one-click approval for urgent posts

## Keyboard Shortcuts (Future Enhancement)

Planned shortcuts:
- `Cmd/Ctrl + Enter` - Approve current post
- `Cmd/Ctrl + R` - Request changes
- `Cmd/Ctrl + D` - Reject
- `Esc` - Close approval dialog

## FAQs

**Q: Can I skip approval for some posts?**
A: Currently all scheduled posts require approval. This ensures quality control.

**Q: What happens if I forget to approve?**
A: Post will not publish. The automatic publisher only posts approved content.

**Q: Can I approve my own posts?**
A: Yes, for solo users. The system treats you as both creator and reviewer.

**Q: How do I know which posts need approval?**
A: Check the orange notification banner or look for ⚠ icons in calendar.

**Q: Can I edit a post after approval?**
A: Yes, but you'll need to approve it again after editing.

## Future Enhancements

Planned features:
- [ ] Multi-user approval chains
- [ ] Role-based permissions (Creator, Reviewer, Admin)
- [ ] Approval history and audit log
- [ ] Email notifications for pending approvals
- [ ] Batch approval interface
- [ ] Approval templates and checklists
- [ ] Time-based auto-approval rules

## Support

For questions about the approval workflow:
- Check this documentation
- Look for ⚠ icons in the calendar
- Orange posts need your attention
- Green box shows review summary
